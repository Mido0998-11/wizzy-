import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `❗ أرسل نصًا لتحويله إلى صوت.\n\nمثال:\n*${usedPrefix + command} مرحباً، هذا صوت غوكو!*`;

  const text = args.join(" ");
  const apiKey = "66b8a002b2694a1b9a0b2fc566a0d554"; // مفتاح VoiceRSS الخاص بك
  const url = `http://api.voicerss.org/?key=${apiKey}&hl=ar-sa&src=${encodeURIComponent(text)}`;

  try {
    const res = await axios.get(url, {
      responseType: "arraybuffer",
    });

    const filePath = path.join(__dirname, "voice.mp3");
    fs.writeFileSync(filePath, res.data);

    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(filePath),
      mimetype: 'audio/mpeg',
      ptt: true
    }, { quoted: m });

    await m.react('✅');
    fs.unlinkSync(filePath); // حذف الملف بعد الإرسال
  } catch (err) {
    console.error(err);
    await m.reply('❌ حدث خطأ أثناء توليد الصوت، حاول لاحقًا.');
  }
};

handler.help = ['الجردل <نص>'];
handler.tags = ['أدوات'];
handler.command = ['الجردل', 'voice'];
handler.limit = false;

export default handler;