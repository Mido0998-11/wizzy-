import { prepareWAMessageMedia, generateWAMessageFromContent, getDevice } from '@whiskeysockets/baileys';
import yts from 'yt-search';
import fs from 'fs';

const handler = async (m, { conn, text, usedPrefix: prefix }) => {
    const device = await getDevice(m.key.id);

    if (!text) return conn.reply(m.chat, '⚠️ من فضلك أدخل اسم الأغنية التي تريد البحث عنها ⚠️', m);

    if (device !== 'desktop' && device !== 'web') {
        const results = await yts(text);
        const videos = results.videos.slice(0, 20);
        const randomIndex = Math.floor(Math.random() * videos.length);
        const randomVideo = videos[randomIndex];

        const messa = await prepareWAMessageMedia({ image: { url: randomVideo.thumbnail }}, { upload: conn.waUploadToServer });
        const interactiveMessage = {
            body: {
                text: `𝗬𝗢𝗨𝗧𝗨𝗕𝗘 － 𝗣𝗟𝗔𝗬\n\n» *العنوان:* ${randomVideo.title}\n» *المدة:* ${randomVideo.duration.timestamp}\n» *الناشر:* ${randomVideo.author.name || 'غير معروف'}\n» *تم النشر:* ${randomVideo.ago}\n» *الرابط:* ${randomVideo.url}\n`
            },
            footer: { text: `${global.dev}`.trim() },
            header: {
                title: ``,
                hasMediaAttachment: true,
                imageMessage: messa.imageMessage,
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: 'خيارات التحميل',
                            sections: videos.map((video) => ({
                                title: video.title,
                                rows: [
                                    { header: video.title, title: video.author.name, description: 'تحميل MP3 (صوت)', id: `${prefix}ytmp3 ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'تحميل MP4 (فيديو)', id: `${prefix}ytmp4 ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'تحميل MP3 كملف', id: `${prefix}ytmp3doc ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'تحميل MP4 كملف', id: `${prefix}ytmp4doc ${video.url}` }
                                ]
                            }))
                        })
                    }
                ],
                messageParamsJson: ''
            }
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage,
                },
            },
        }, { userJid: conn.user.jid, quoted: null });
        conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } else {
        const idioma = global.db.data.users[m.sender].language;
        const _translate = JSON.parse(fs.readFileSync(`./language/${idioma}.json`));
        const traductor = _translate.plugins.buscador_yts;
        const results = await yts(text);
        const tes = results.all;
        const teks = results.all.map((v) => {
            if (v.type === 'video') return `
° *_${v.title}_*
↳ 🫐 *_الرابط :_* ${v.url}
↳ 🕒 *_المدة :_* ${v.timestamp}
↳ 📥 *_تاريخ النشر :_* ${v.ago}
↳ 👁 *_عدد المشاهدات :_* ${v.views}`;
        }).filter(v => v).join('\n\n——————————————\n\n');
        conn.sendFile(m.chat, tes[0].thumbnail, 'error.jpg', teks.trim(), m);
    }
};

handler.help = ['pliay *<النص>*'];
handler.tags = ['dl'];
handler.command = ['pliay'];
handler.register = true;

export default handler;