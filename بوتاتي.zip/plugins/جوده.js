import axios from "axios";
import uploadImage from "../lib/uploadImage.js"; // تأكد من وجود الملف
import { generateWAMessageFromContent } from "@whiskeysockets/baileys";

const handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || q.mediaType || "";

    if (!mime.startsWith("image/")) {
      return conn.reply(
        m.chat,
        `📷 *رجاءً رد على صورة لاستخدام الأمر:* \n${usedPrefix + command}`,
        m
      );
    }

    await m.react("🕓");

    const imgBuffer = await q.download?.();
    if (!imgBuffer) throw new Error("فشل تنزيل الصورة");

    const urlSubida = await uploadImage(imgBuffer);
    if (!urlSubida) throw new Error("فشل رفع الصورة");

    const upscaledBuffer = await getUpscaledImage(urlSubida);
    if (!upscaledBuffer) throw new Error("فشل تحسين الصورة");

    const caption = `
╔═══❪ 𓆩⚡𝐆𝐎𝐊𝐔 𝐁𝐎𝐓⚡𓆪 ❫═══╗
║ ✅ تم تحسين الصورة بنجاح!
║ يمكنك استقبال صورتك الآن 👇
╚════════════════════╝
    `.trim();

    await conn.sendMessage(
      m.chat,
      {
        image: upscaledBuffer,
        caption,
      },
      { quoted: m }
    );

    await m.react("✅");
  } catch (e) {
    console.error("حدث خطأ:", e);
    await m.react("❌");
    conn.reply(
      m.chat,
      `❌ *فشل تحسين الصورة*\n\n📌 يرجى المحاولة لاحقًا.`,
      m
    );
  }
};

handler.help = ["تحسين", "hd", "remini"];
handler.tags = ["tools"];
handler.command = ["تحسين", "hd", "remini"];
handler.register = true;
export default handler;

async function getUpscaledImage(imageUrl) {
  const apiUrl = `https://api.siputzx.my.id/api/iloveimg/upscale?image=${encodeURIComponent(
    imageUrl
  )}`;
  const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
  return Buffer.from(response.data);
}