import axios from 'axios';

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`❗ اكتب اسم الفيديو أو وصفه بعد كلمة "تحميل"\n\nمثال:\n${usedPrefix + command} انمي اكشن قصير`);

  m.react("⏳");

  try {
    let res = await axios.get(`https://apis.wilamdz.repl.co/search/tiktoksearch?query=${encodeURIComponent(text)}`);
    let results = res.data?.meta;

    if (!results || !Array.isArray(results) || results.length === 0) {
      return m.reply(`❌ لم يتم العثور على نتائج لـ "${text}".`);
    }

    // فلترة الفيديوهات القصيرة فقط (مدة أقل من دقيقة)
    let shortVideos = results.filter(v => v.duration && v.duration < 60);

    if (shortVideos.length === 0) {
      return m.reply("❌ لم يتم العثور على مقاطع قصيرة أقل من دقيقة.");
    }

    let selected = shortVideos.slice(0, 3); // إرسال 3 فقط

    for (let vid of selected) {
      await conn.sendFile(m.chat, vid.hd, '', `🎬 *${vid.title}*\n⏱️ المدة: ${vid.duration} ثانية\n🔗 المصدر: TikTok`, m);
      await conn.delay(1000);
    }

    m.react("✅");

  } catch (err) {
    console.error(err);
    m.react("❌");
    return m.reply("⚠️ حصل خطأ أثناء تحميل المقاطع.");
  }
};

handler.help = ['تحميل <كلمة>'];
handler.tags = ['downloader'];
handler.command = ['تحميل'];
handler.limit = true;

export default handler;