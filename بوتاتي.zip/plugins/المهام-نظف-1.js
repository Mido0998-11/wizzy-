import { createHash } from 'crypto';

let handler = async (m, { conn }) => {
  try {
    const targetGroup = '120363404287423768@g.us';
    let deleted = false;

    if (global.db.data.chats && global.db.data.chats[targetGroup]) {
      delete global.db.data.chats[targetGroup];
      deleted = true;
    }

    if (global.db.data.stats && global.db.data.stats[targetGroup]) {
      delete global.db.data.stats[targetGroup];
      deleted = true;
    }

    if (global.db.data.msgs && global.db.data.msgs[targetGroup]) {
      delete global.db.data.msgs[targetGroup];
      deleted = true;
    }

    if (deleted) {
      conn.reply(m.chat, `*🧹 تم حذف جميع بيانات الدردشةة ${targetGroup} من قاعدة البيانات*`, m);
    } else {
      conn.reply(m.chat, `*ℹ️ لا توجد بيانات مرتبطة ب هذه الدردشة ${targetGroup}*`, m);
    }
  } catch (e) {
    console.error(e);
    conn.reply(m.chat, `*فيه غلط هنا: ${e.message}*`, m);
  }
};

handler.help = ['تست'];
handler.tags = ['owner'];
handler.command = ['نظف-1'];
handler.rowner = false;

export default handler;