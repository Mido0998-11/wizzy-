import fetch from 'node-fetch';

let toM = a => '@' + a.split('@')[0];

async function handler(m, { conn, groupMetadata }) {
    let ps = groupMetadata.participants.map(v => v.id);
    let a = ps[Math.floor(Math.random() * ps.length)];
    let b;
    do {
        b = ps[Math.floor(Math.random() * ps.length)];
    } while (b === a);

    // صورة الإعلان
    const image = 'https://telegra.ph/file/0dde86d97f9cab0ea3ccb.jpg';

    await conn.sendMessage(m.chat, {
        image: { url: image },
        caption: `
╔════ •✧✧• ════╗
    *إعــلان زفــاف رسمي*  
╚════ •✧✧• ════╝

*➤ الــعــريـس:* ${toM(a)}
*➤ الــعــروس:* ${toM(b)}

*ألف ألف مبروك للعروسين، نسأل الله أن يجمع بينكما في خير ويرزقكم الذرية الصالحة.*  
> كل واحد يجيب معاه الكيك والبخور والحلويات  
        `.trim(),
        mentions: [a, b]
    }, { quoted: m });
}

handler.help = ['formarpareja'];
handler.tags = ['main', 'fun'];
handler.command = ['زوجني', 'زواج'];
handler.group = true;

export default handler;