// - OfcKing >> https://github.com/OfcKing

import axios from 'axios';

const handler = async (m, { conn, args }) => {
    if (!args[0]) {
        await conn.reply(m.chat, '🖌️✨ *من فضلك أرسل وصفًا لتوليد الصورة الخيالية...*\n\nمثال: `تخيل قط يطير في السماء`', m);
        return;
    }

    const prompt = args.join(' ');
    const apiUrl = `https://eliasar-yt-api.vercel.app/api/ai/text2img?prompt=${encodeURIComponent(prompt)}`;

    try {
        await m.react('🎨');
        await conn.reply(m.chat, '⌛ *جارٍ توليد الصورة بناءً على خيالك...*\n\nالطلب: ' + prompt, m);

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        await conn.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `🖼️ *تم توليد الصورة بنجاح!*\n\n✨ *خيالك أصبح واقعًا الآن!*\n\n🤖 _بواسطة غوكو_`
        }, { quoted: m });

        await m.react('✅');
    } catch (error) {
        console.error('حدث خطأ أثناء توليد الصورة:', error);
        await m.react('❌');
        await conn.reply(m.chat, '❌ *عذرًا، لم أتمكن من توليد الصورة حاليًا.*\n📌 حاول مرة أخرى لاحقًا.\n\n🤖 _غوكو في خدمتك_', m);
    }
};

handler.command = ['تخيل'];
handler.help = ['تخيل <وصف>'];
handler.tags = ['الذكاء_الاصطناعي'];
handler.register = true;

export default handler;