import PhoneNumber from 'awesome-phonenumber'

let handler = async (m, { conn }) => {
  // تعريف رقم المطور (بدون @s.whatsapp.net)
  let nomorown = '249967185716' // ← عدل هذا الرقم لرقمك الحقيقي

  // جلب نبذات
  let حالة_المطور = await conn.fetchStatus(nomorown + '@s.whatsapp.net').catch(_ => ({ status: 'لا توجد نبذة' }))
  let حالة_البوت = await conn.fetchStatus(conn.user.jid).catch(_ => ({ status: 'لا توجد نبذة' }))
  let نبذة_المطور = حالة_المطور.status?.toString() || 'لا توجد نبذة'
  let نبذة_البوت = حالة_البوت.status?.toString() || 'لا توجد نبذة'

  // إرسال جهة الاتصال
  await إرسال_جهات_اتصال(conn, m.chat, [
    [
      `${nomorown}`,
      `👑 مطور البوت`,
      `𝑪𝒓𝒆𝒂𝒕𝒐𝒓 𝑴𝒐𝒉𝒂𝒎𝒎𝒂𝒅 𝑨𝒅𝒂𝒍`,
      `💌 راسل باحترام`,
      `goku@gmail.com`,
      `🇸🇩 السودان`,
      `https://youtube.com/@gokubot`, // global.yt
      نبذة_المطور
    ],
    [
      `${conn.user.jid.split('@')[0]}`,
      `🤖 غوكو بوت`,
      `COKU BOT`, // packname
      `⚠️ لا ترسل سبام`,
      `goku@gmail.com`,
      `🇸🇩 السودان`,
      `https://github.com/COKU-BOT`, // md
      نبذة_البوت
    ]
  ], m)
}

handler.help = ['المطور', 'owner']
handler.tags = ['info']
handler.command = ['المطور', 'owner', 'المالك', 'مطور']

export default handler

async function إرسال_جهات_اتصال(conn, jid, البيانات, m, خيارات = {}) {
  if (!Array.isArray(البيانات[0]) && typeof البيانات[0] === 'string') البيانات = [البيانات]
  let جهات = []

  for (let [رقم, اسم, صف1, صف2, بريد, دولة, موقع, نبذة] of البيانات) {
    رقم = رقم.replace(/[^0-9]/g, '')
    let vcard = `
BEGIN:VCARD
VERSION:3.0
N:;${اسم.replace(/\n/g, '\\n')};;;
FN:${اسم.replace(/\n/g, '\\n')}
item.ORG:${صف1}
item1.TEL;waid=${رقم}:${PhoneNumber('+' + رقم).getNumber('international')}
item1.X-ABLabel:${صف2}
item2.EMAIL;type=INTERNET:${بريد}
item2.X-ABLabel:📧 بريد
item3.ADR:;;${دولة};;;;
item3.X-ABADR:ac
item3.X-ABLabel:🌍 الدولة
item4.URL:${موقع}
item4.X-ABLabel:🌐 الموقع
item5.X-ABLabel:${نبذة}
END:VCARD`.trim()

    جهات.push({ vcard, displayName: اسم })
  }

  return await conn.sendMessage(jid, {
    contacts: {
      displayName: `${جهات.length} جهة اتصال`,
      contacts: جهات
    }
  }, {
    quoted: m,
    ...خيارات
  })
}