import yts from 'yt-search';
import fetch from 'node-fetch';

let handler = async (m, { conn, text, botname }) => {
  if (!text) return m.reply("`اكــتــب اســم فــيـديـــو صــحـيــح.`");
 
 await m.react('⏱️')

  let loadingMsg = await m.reply("`❲ 𓆩... وي̣̇ــــ͟͞⚡͟͞ـ͟͞ـ̣̇ـــت ...𓆪 ❳`");

  try {
    let search = await yts(text);
    let video = search.videos[0];

    if (!video) return m.reply("❌ *الـتنزيل غير متاح.*");

    let apiUrl = `https://keith-api.vercel.app/download/dlmp4?url=${video.url}`;
    let response = await fetch(apiUrl);
    let data = await response.json();

    if (!data.status || !data.result) return m.reply("🚫 *خطأ.*");

    const { title, downloadUrl, format, quality } = data.result;

    await conn.sendMessage(m.chat, { delete: loadingMsg.key });

    let caption = ``;

    await conn.sendMessage(m.chat, {
      video: { url: downloadUrl },
      mimetype: "video/mp4",
      caption: `*𝐇𝐈𝐆𝐇 𝐐𝐔𝐀𝐋𝐈𝐓𝐘 𝐕𝐈𝐃𝐄𝐎*

> *♯ 𝐇 Ꭵ 𝐗 • 𝐁❍𝐓 ✸*`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363365904902973@newsletter',
          newsletterName: '⚡   ♔𓆩𝗖𝗢𝗞𝗨 𝗕𝗢𝗧𓆪♔   𝐁𝐎𝐓   𝐕𝐈𝐃𝐄𝐎   𝐏𝐋𝐀𝐘𝐄𝐑   ⚡',
          serverMessageId: 143
        }
      }
    });
await m.react('✅')
  } catch (error) {
    console.error("❌ Error:", error.message);
    m.reply("❌ *خطا جرب تاني.*");
  }
};

handler.help = ["video", "mp4"];
handler.tags = ["downloader"];
handler.command = ["فيديو", "فيد"];

export default handler;