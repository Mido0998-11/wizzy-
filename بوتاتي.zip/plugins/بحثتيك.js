import fetch from 'node-fetch';

let handler = async (m, { conn, text, command }) => {
  if (!text) return conn.reply(m.chat, `✦︙اكتب كلمة للبحث مثل:\n*.بحثتيك شانكس*`, m);

  try {
    let res = await fetch(`https://www.takamura.site/api/search/tik-img?keywords=${encodeURIComponent(text)}`);
    let json = await res.json();

    if (!json || !json.result || json.result.length === 0)
      return conn.reply(m.chat, '✖︙لم يتم العثور على نتائج.', m);

    let result = json.result[0]; // أول نتيجة فقط
    let message = `*⌯ النتيـجة الأولى للبحث عن: "${text}"*\n\n`
                + `*⌬ العنوان:* ${result.title || 'غير متوفر'}\n`
                + `*⌬ المستخدم:* ${result.author_name || 'غير معروف'}`;

    await conn.sendMessage(m.chat, {
      image: { url: result.cover }, 
      caption: message,
      buttons: [
        { buttonId: `.بحثتيك ${text}`, buttonText: { displayText: 'بحث مجددًا' }, type: 1 },
        { buttonId: result.play, buttonText: { displayText: 'رابط الفيديو' }, type: 1 }
      ],
      footer: '• COKU BOT | بحث تيك توك',
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    await conn.reply(m.chat, '✖︙حدث خطأ أثناء جلب النتائج.', m);
  }
};

handler.help = ['بحثتيك <كلمة>'];
handler.tags = ['tools'];
handler.command = ['بحثتيك'];

export default handler;