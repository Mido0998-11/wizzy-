//المصدر ايتادوري
//كود عمل جلسه بازرار
//api https://whatsapp.com/channel/0029VaJxI9uJkK7BedTH0D11/3904
import axios from 'axios';
import { generateWAMessageFromContent } from '@whiskeysockets/baileys';

const handler = async (m, { conn, text }) => {
    if (!text || isNaN(text)) {
        return m.reply('⚠️ من فضلك أرسل الرقم بالشكل التالي:\nمثال: .جلسة 967738512629');
    }

    const config = {
        method: 'GET',
        url: `https://knight-bot-paircode.onrender.com/code?number=${text}`,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 9; CPH1923 Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.87 Mobile Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'sec-ch-ua-platform': '"Android"',
            'sec-ch-ua': '"Chromium";v="136", "Android WebView";v="136", "Not.A/Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': 'https://knight-bot-paircode.onrender.com/',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'priority': 'u=1, i'
        }
    };

    try {
        const res = await axios.request(config);
        const code = res.data?.code;

        if (!code) {
            return m.reply('❌ لم يتم العثور على الكود! حاول مرة أخرى.');
        }

        const codeMessage = `✅ تم جلب كود الجلسة للرقم ${text}.\n\n🔑 اضغط الزر لنسخ الكود.`;

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: codeMessage },
                        footer: { text: `${global.wm || 'ITADORI BOT'}` },
                        header: { hasMediaAttachment: false },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'cta_copy',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: 'نسخ الكود',
                                        copy_code: code,
                                        id: 'copy-session-code'
                                    })
                                }
                            ],
                            messageParamsJson: "",
                        },
                    }
                }
            }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error(err);
        await conn.sendMessage(m.chat, {
            text: `❌ حدث خطأ أثناء جلب الكود:\n\n${err.message}`
        });
    }
};

handler.help = ['جلسة'];
handler.tags = ['tools'];
handler.command = /^(جلسه|جلسة|سيسيو|ربط|session|sess|sessio|link|connect)$/i;
export default handler;
//مصدر الكود تائب🧞: https://whatsapp.com/channel/0029VbAa17UJkK7J5EAGyT1h