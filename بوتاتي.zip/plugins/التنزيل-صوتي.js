import axios from "axios";
import ytSearch from "yt-search";

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("`تـحـب تـسـمـع اي ي فنان` 🎸");

  let loadingMsg = await m.reply(" `❲ 𓆩... وي̣̇ــــ͟͞⚡͟͞ـ͟͞ـ̣̇ـــت ...𓆪 ❳`");

  try {
    let search = await ytSearch(text);
    let video = search.videos[0];

    if (!video) return m.reply("`ملقيتش ال انت عايزو` 🦆💔");

    let link = video.url;
    let apis = [
      `https://apis.davidcyriltech.my.id/youtube/mp3?url=${link}`,
      `https://api.ryzendesu.vip/api/downloader/ytmp3?url=${link}`,
      `https://api.akuari.my.id/downloader/youtubeaudio?link=${link}`
    ];

    // Fetch from the first working API
    let response;
    for (let api of apis) {
      try {
        response = await axios.get(api);
        if (response.data.status === 200 || response.data.success) break; // Exit loop if success
      } catch (error) {
        console.error(`❌ API Error: ${api} - ${error.message}`);
        continue; // Try the next API
      }
    }

    if (!response || !response.data || !(response.data.status === 200 || response.data.success)) {
      return m.reply("⚠️ *خطأ.*");
    }

    let data = response.data.result || response.data;
    let audioUrl = data.downloadUrl || data.url;
    let songData = {
      title: data.title || video.title,
      artist: data.author || video.author.name,
      thumbnail: data.image || video.thumbnail
    };

    // Delete loading message
    await conn.sendMessage(m.chat, { delete: loadingMsg.key });

    let caption = `▭▬▭▬▭▬▭▬▭▬▭▬▭▬ 
*ـ𓉘🎧 𝗪𝗶𝘇𝘇𝗬  Ⲃ ❍ Т - M U S Ꭵ C  🎧𓉝ـ*
▭▬▭▬▭▬▭▬▭▬▭▬▭▬
📌 *الـعـنـوان:* ${songData.title}
👤 *الـمـغـنـي:* ${songData.artist}  
▭▬▭▬▭▬▭▬▭▬▭▬▭▬
> ـ-> *♯ 𝗖𝗢𝗞𝗨 • 𝐁❍𝐓 ☘️*`;

    await conn.sendMessage(m.chat, {
      image: { url: songData.thumbnail },
      caption: caption,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363365904902973@newsletter',
          newsletterName: '𝗪𝗶𝘇𝘇𝗬 𝐌𝐔𝐒𝐈𝐂 𝐏𝐋𝐀𝐘𝐄𝐑 ⚡',
          serverMessageId: 143
        }
      }
    });

    // Send audio file
    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: "audio/mp4",
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363365904902973@newsletter',
          newsletterName: '𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 𝐌𝐔𝐒𝐈𝐂 𝐏𝐋𝐀𝐘𝐄𝐑 🎸',
          serverMessageId: 143
        }
      }
    });

    // Send MP3 as document
    await conn.sendMessage(m.chat, {
      document: { url: audioUrl },
      mimetype: "audio/mp3",
      fileName: `${songData.title}.mp3`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363365904902973@newsletter',
          newsletterName: ' 𝗪𝗶𝘇𝘇𝗬 𝐌𝐔𝐒𝐈𝐂 𝐏𝐋𝐀𝐘𝐄𝐑 🍨',
          serverMessageId: 143
        }
      }
    });

    m.reply("`اسـتـمـتـع بـاغـانـيـڪ الـمـفـضـلـة وعـش في عـالـم المـوسـيـقـي مـع هـيـڪس بـوت` 🎶");

  } catch (error) {
    console.error("❌ Error:", error.message);
    m.reply("❌ *جـرب تـاني.*");
  }
};

handler.help = ["song"];
handler.tags = ["downloader"];
handler.command = /^صوتي$/i;

export default handler;