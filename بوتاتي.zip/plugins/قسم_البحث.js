import fs from 'fs'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'

let handler = async (m, { conn, usedPrefix }) => {
try {
  let img = await (await fetch('https://files.catbox.moe/dno3x7.jpg')).buffer()
  let { exp, limit, level, money, role } = global.db.data.users[m.sender]
  let { min, xp, max } = xpRange(level, global.multiplier)
  let name = conn.getName(m.sender)
  let tag = '@' + m.sender.split('@')[0]

  const caption = `
╭━━〔 *𝗪𝗶𝘇𝘇𝗬 و 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧* 〕━━╮
┃⌯ الاسـم : *${name}*
┃⌯ المستـوى : *${level}*
┃⌯ الخبرة : *${exp}/${max}*
┃⌯ الرتبة : *${role}*
┃⌯ الرصيد : *${money}*
╰━━━━━━━━━━━━━━╯

⌯︙ *قائمة البحث العام*:
┌──⊰
│• .بحث [النص]
│• .صوره [الكلمة]
│• .بين [الكلمة]
│• .ويكي [الكلمة]
└──⊰

⌯︙ *ملاحظة*: يمكنك استخدام أي قناة أو رابط.
⌯︙ *البوت تحت إدارة 𝗪𝗶𝘇𝘇𝗬 و 𝗖𝗢𝗞𝗨.*

`.trim()

  await conn.sendMessage(m.chat, {
    image: img,
    caption,
    mentions: [m.sender]
  }, { quoted: m })

} catch (e) {
  console.error(e)
  m.reply('حدث خطأ أثناء عرض القائمة.')
}
}

handler.command = /^بحثي|قسم-البحث|بتحث$/i
export default handler