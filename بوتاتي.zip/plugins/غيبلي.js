import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

async function ghibliArt(prompt) {
  try {
    const { data } = await axios.post('https://ghibliart.net/api/generate-image', { prompt }, {
      headers: {
        'accept': '*/*',
        'content-type': 'application/json',
        'origin': 'https://ghibliart.net',
        'referer': 'https://ghibliart.net/',
        'user-agent': 'Mozilla/5.0',
      }
    });

    const img = data?.image || data?.url;
    const tmp = path.join(process.cwd(), 'tmp');
    if (!fs.existsSync(tmp)) fs.mkdirSync(tmp);

    const filename = `${prompt.replace(/\s+/g, '_')}-${Date.now()}.jpg`;
    const filepath = path.join(tmp, filename);

    if (img.startsWith('data:image/') || img.startsWith('iVBORw')) {
      const base64 = img.replace(/^data:image\/\w+;base64,/, '');
      fs.writeFileSync(filepath, Buffer.from(base64, 'base64'));
    } else {
      const { data: buffer } = await axios.get(img, { responseType: 'arraybuffer' });
      fs.writeFileSync(filepath, buffer);
    }

    return filepath;
  } catch (error) {
    throw new Error(`🧞 حدث خطأ أثناء توليد الصورة: ${error.message}`);
  }
}

let handler = async (m, { conn, args, command, usedPrefix }) => {
  try {
    if (!args[0]) {
      return m.reply(`🧞 يرجى كتابة وصف للصورة التي تريد توليدها بأسلوب غيبلي.\n\n📌 طريقة الاستخدام:\n⤷ *.${command} فتاة تمشي تحت المطر*\n\n🅜🅘🅝🅐🅣🅞 🅑🅞🅣🧞`);
    }

    const prompt = args.join(' ');
    m.reply('🧞 جاري توليد الصورة، يرجى الانتظار...');

    const filePath = await ghibliArt(prompt);
    const media = await prepareWAMessageMedia({ image: fs.readFileSync(filePath) }, { upload: conn.waUploadToServer });

    const messageText = `🧞 تم توليد صورة بأسلوب غيبلي بناءً على وصفك:\n「 *${prompt}* 」\n\n🅜🅘🅝🅐🅣🅞 🅑🅞🅣🧞`;

    const buttons = [
      {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: '⌈🚀╎توليد صورة أخرى╎🚀⌋',
          id: `${usedPrefix}${command} ${prompt}`
        })
      }
    ];

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: messageText },
            footer: { text: "© Minato Bot" },
            header: {
              hasMediaAttachment: true,
              imageMessage: media.imageMessage
            },
            nativeFlowMessage: {
              buttons: buttons,
              messageParamsJson: ''
            }
          }
        }
      }
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    fs.unlinkSync(filePath); // حذف الملف بعد الإرسال
  } catch (e) {
    m.reply(`🧞 ${e.message}\n\n🅜🅘🅝🅐🅣🅞 🅑🅞🅣🧞`);
  }
};

// الأوامر باللغتين
handler.help = ['ghibliart', 'غيبلي'];
handler.command = ['ghibliart', 'غيبلي'];
handler.tags = ['ai'];

export default handler;