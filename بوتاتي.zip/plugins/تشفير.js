import JavaScriptObfuscator from "javascript-obfuscator"

let Mori = async (m, { args }) => {
    try {
        const modes = ["صعب", "متوسط"]
        const usage = "من فضلك قم بالرد على كود JavaScript الذي تريد تشفيره.\n\n*مثال:*\nتشفير صعب"
        if (!m.quoted) return m.reply(usage)

        const type = args[0]?.toLowerCase()
        if (!modes.includes(type)) return m.reply(usage)

        const inputCode = m.quoted.text
        const message = type === "صعب" ? await Encrypt(inputCode) : await MediumEncrypt(inputCode)

        return m.reply(message)

    } catch (e) {
        console.error(e)
await m.reply("حدث خطأ أثناء التشفير:\n" + e.message)
    }
}

Mori.help = ['تشفير صعب', 'تشفير متوسط']
Mori.tags = ['أدوات']
Mori.command = /^تشفير$/i
Mori.limit = true
export default Mori

async function Encrypt(code) {
    const result = JavaScriptObfuscator.obfuscate(code, {
        compact: true,
        controlFlowFlattening: true,
        controlFlowFlatteningThreshold: 1,
        numbersToExpressions: true,
        simplify: true,
        stringArrayShuffle: true,
        splitStrings: true,
        stringArrayThreshold: 1
    })
    return result.getObfuscatedCode()
}

async function MediumEncrypt(code) {
    const result = JavaScriptObfuscator.obfuscate(code, {
        compact: true,
        simplify: true,
        stringArray: true,
        stringArrayThreshold: 0.75
    })
    return result.getObfuscatedCode()
}