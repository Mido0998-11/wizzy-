let handler = async (m, { conn, args, command }) => {
  let user = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  let name = conn.getName(user)
  let profile

  try {
    profile = await conn.profilePictureUrl(user, 'image')
  } catch {
    profile = 'https://telegra.ph/file/265c672094dfa87caea19.jpg' // صورة افتراضية
  }

  await conn.sendFile(m.chat, profile, 'profile.jpg', `
👤 *الاسم:* ${name}
🖼️ *صورة البروفايل بنجاح!*
✨ *طلب بواسطة:* ${conn.getName(m.sender)}

⚡ *غوكو دايمًا حاضر!*
  `.trim(), m, { mentions: [user] })
}

handler.command = ['صورته', 'صورتك', 'صورة']
handler.tags = ['tools']
handler.help = ['صورة [منشن]']

export default handler