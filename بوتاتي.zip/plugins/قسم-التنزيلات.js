import fs from 'fs'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
const { levelling } = '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'
import { promises } from 'fs'
import { join } from 'path'

let handler = async (m, { conn, usedPrefix, usedPrefix: _p, __dirname, text, isPrems }) => {
try {
let vn = './Menu2.jpg'
let pp = imagen4
let d = new Date(new Date + 3600000)
let locale = 'ar'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
let _uptime = process.uptime() * 1000
let uptime = clockString(_uptime)
let user = global.db.data.users[m.sender]
let { money, joincount } = global.db.data.users[m.sender]
let { exp, limit, level, role } = global.db.data.users[m.sender]
let { min, xp, max } = xpRange(level, global.multiplier)
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length 
let more = String.fromCharCode(8206)
let readMore = more.repeat(850)   
let taguser = '@' + m.sender.split("@s.whatsapp.net")[0]

let str = `
╭─❍ *‹  𝗪𝗶𝘇𝘇𝗬 - COKU  ›*
│ *قسم التنزيلات الرسمي*
╰───────────────
⌬ .ميجا
⌬ .اديت
⌬ .اديت-سيارات
⌬ .اديت-كورة
⌬ .فديو
⌬ .صوره
⌬ .خلفيات
⌬ .ميديافاير
⌬ .اغنية
⌬ .تطبيق
╭─────┈✧
│ *المطور:*  𝗪𝗶𝘇𝘇𝗬
╰─────┈✧`.trim()

let buttonMessage = {
  image: pp,
  caption: str,
  mentions: [m.sender],
  footer: '𝗪𝗶𝘇𝘇𝗬 - COKU',
  headerType: 4,
  contextInfo: {
    mentionedJid: [m.sender],
    externalAdReply: {
      showAdAttribution: false,
      mediaType: 1,
      title: '✦ 𝗪𝗶𝘇𝘇𝗬 - COKU • بوت التنزيلات',
      body: 'أقوى قسم تنزيلات يومية',
      thumbnail: pp,
      sourceUrl: ''
    }
  }
}

conn.sendMessage(m.chat, buttonMessage, { quoted: m })

} catch {
  conn.reply(m.chat, '[❗حدث خطأ أثناء تنفيذ الأمر❗]', m)
}
}

handler.command = /^(ق 4|قسم-التنزيلات|ق4|ق_4)$/i
handler.exp = 20
handler.fail = null
export default handler

function clockString(ms) {
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}