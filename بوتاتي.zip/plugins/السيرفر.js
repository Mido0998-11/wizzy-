import os from 'os'
import moment from 'moment-timezone'

const handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, { react: { text: '🛰️', key: m.key } })

  const used = process.memoryUsage()
  const totalMem = os.totalmem()
  const cpu = os.cpus()
  const cpuModel = cpu[0].model
  const cpuSpeed = cpu[0].speed

  const users = Object.entries(global.db.data.users)
  const totalUsers = users.length

  const activeUsers = users
    .sort((a, b) => b[1].exp - a[1].exp)
    .slice(0, 5)
    .map(([jid, user], i) => `${i + 1}. @${jid.split('@')[0]} ⟿ ${user.exp} XP`)
    .join('\n')

  let hours = Array(24).fill(0)
  users.forEach(([_, u]) => {
    const h = new Date(u.lastseen || 0).getHours()
    if (!isNaN(h)) hours[h]++
  })
  const peakHour = hours.indexOf(Math.max(...hours))

  const serverInfo = `
╭──〔 🛰️ 𝑪𝑶𝑲𝑼 𝑺𝑬𝑹𝑽𝑬𝑹 〕──⬣
│ 🧠 الذاكرة المستخدمة: ${(used.heapUsed / 1024 / 1024).toFixed(2)} MB
│ 💾 الذاكرة الكلية: ${(totalMem / 1024 / 1024).toFixed(2)} MB
│ ⚙️ نوع المعالج: ${cpuModel}
│ 🚀 سرعة المعالج: ${cpuSpeed} MHz
│ 👥 المستخدمين: ${totalUsers}
╰──────────────⬣

👑 *أكثر المستخدمين نشاطًا:*
${activeUsers || 'لا يوجد نشاط بعد'}

📈 *وقت الذروة:* الساعة ${peakHour}:00
`.trim()

  const buttons = [
    { buttonId: '.السيرفر', buttonText: { displayText: '🛰️ حالة السيرفر' }, type: 1 },
    { buttonId: '.النشاط', buttonText: { displayText: '👑 المستخدمين النشطين' }, type: 1 },
    { buttonId: '.الذروة', buttonText: { displayText: '📈 وقت الذروة' }, type: 1 }
  ]

  const buttonMessage = {
    text: serverInfo,
    footer: '✦ 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 • 𝗕𝗬 𝗠𝗢𝗛𝗔𝗠𝗘𝗗 𝗔𝗗𝗘𝗟 ✦',
    buttons: buttons,
    headerType: 1
  }

  await conn.sendMessage(m.chat, buttonMessage, { quoted: m })
}

handler.command = ['السيرفر']
export default handler