import axios from 'axios'

const FILTERS = ['Coklat', 'Hitam', 'Nerd', 'Piggy', 'Carbon', 'Botak']

let yeon = async (m, { conn, text, usedPrefix, command }) => {
    const q = m.quoted || m
    const mime = (q.msg || q).mimetype || ''
    
    if (!/image/.test(mime)) {
        await conn.sendMessage(m.chat, { 
            react: { text: "❌", key: m.key } 
        })
        return conn.sendMessage(m.chat, {
            text: `✨ *الفلاتر المتوفرة* ✨
▏ [ *Hitam:* فلتر أسود
▏ [ *Coklat:* فلتر بني
▏ [ *Nerd:* فلتر النظارات
▏ [ *Piggy:* فلتر خنزير
▏ [ *Carbon:* فلتر كاربون
▏ [ *Botak:* فلتر أصلع

🌟 *طريقة الاستخدام:*
قم بالرد على صورة أو أرسل صورة مع كتابة:
*${usedPrefix + command} <اسم الفلتر>*

مثال:
*${usedPrefix + command} hitam*`
        })
    }

    try {
        await conn.sendMessage(m.chat, { 
            react: { text: "🎨", key: m.key } 
        })

        const buffer = await q.download()
        const base64Input = buffer.toString('base64')

        const args = text.split(' ')
        const selectedFilter = args[0]?.toLowerCase() || 'hitam'
        const validFilter = FILTERS.find(f => f.toLowerCase() === selectedFilter)
        
        if (!validFilter) {
            throw new Error(`⚠️ الفلتر غير متوفر. يمكنك اختيار واحد من: ${FILTERS.join(', ')}`)
        }

        const res = await axios.post('https://wpw.my.id/api/process-image', {
            imageData: base64Input,
            filter: validFilter.toLowerCase()
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Origin': 'https://wpw.my.id',
                'Referer': 'https://wpw.my.id/'
            }
        })

        const dataUrl = res.data?.processedImageUrl
        if (!dataUrl?.startsWith('data:image/')) {
            throw new Error('⚠️ فشل معالجة الصورة')
        }

        const base64Output = dataUrl.split(',')[1]
        const processedBuffer = Buffer.from(base64Output, 'base64')

        await conn.sendMessage(m.chat, {
            image: processedBuffer,
            caption: `✨ *تم تطبيق الفلتر بنجاح*
🌸 *الفلتر:* ${validFilter}
🔗 *المصدر:* https://wpw.my.id`
        })

        await conn.sendMessage(m.chat, { 
            react: { text: "✨", key: m.key } 
        })

    } catch (e) {
        console.error('Error:', e.message)
        await conn.sendMessage(m.chat, { 
            react: { text: "❌", key: m.key } 
        })
        await conn.sendMessage(m.chat, {
            text: `⚠️ *عذرًا، حدث خطأ أثناء المعالجة*  
${e.message || 'ربما الخدمة غير متاحة حاليًا، جرب لاحقًا.'}`
        })
    }
}

yeon.help = ['تلوين <فلتر>', 'فلتر <فلتر>']
yeon.tags = ['صور']
yeon.command = /^(تلوين|فلتر)$/i
yeon.register = true
yeon.limit = true
export default yeon
```