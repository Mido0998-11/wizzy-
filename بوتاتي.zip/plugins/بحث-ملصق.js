import axios from "axios";
import * as cheerio from "cheerio";
import { Sticker } from 'wa-sticker-formatter';

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

async function gifsSearch(q) {
    try {
        const randomPos = Math.floor(Math.random() * 1000);
        const searchUrl = `https://tenor.com/search/${q}-gifs?pos=${randomPos}`;
        const { data } = await axios.get(searchUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
        });

        const $ = cheerio.load(data);
        const results = [];

        $("figure.UniversalGifListItem").each((i, el) => {
            const $el = $(el);
            const img = $el.find("img");
            const gifUrl = img.attr("src");
            const alt = img.attr("alt") || "بدون وصف";
            const detailPath = $el.find("a").first().attr("href");

            if (gifUrl && gifUrl.endsWith('.gif') && detailPath) {
                results.push({
                    gif: gifUrl,
                    alt,
                    link: "https://tenor.com" + detailPath
                });
            }
        });

        return shuffleArray(results);
    } catch (error) {
        console.error("❌ خطأ في جلب صور GIF:", error);
        return [];
    }
}

const handler = async (m, { conn, text, command }) => {
    const args = text.trim().split(/\s+/);
    if (!args.length) {
        return m.reply(`✨ أرسل كلمة للبحث عن ملصقات متحركة\n\n✧ مثال:\n.${command} ناروتو\n.${command} قط`);
    }

    const query = args.join(" ");
    const maxStickers = 15;

    try {
        const gifs = await gifsSearch(query);
        if (!gifs.length) return m.reply(`⚠️ لم أجد نتائج للكلمة: *${query}*`);

        const actualCount = Math.min(maxStickers, gifs.length);
        await m.reply(`💫 تم العثور على *${gifs.length}* نتيجة\n📤 جاري إرسال *${actualCount}* ملصقات متحركة...\n\n⌯ 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 ⌯`);

        for (const item of gifs.slice(0, actualCount)) {
            try {
                const sticker = new Sticker(item.gif, {
                    pack: `𝗖𝗢𝗞𝗨 𝗕𝗢𝗧`,
                    author: `تلك 𝗪𝗶𝘇𝘇𝗬 مطور بوت غوكو`,
                    type: 'full',
                    quality: 70
                });

                await conn.sendMessage(m.chat, await sticker.toMessage(), {
                    quoted: m
                });

                await new Promise(resolve => setTimeout(resolve, 700));
            } catch (error) {
                console.error(`⚠️ فشل تحويل صورة إلى ملصق`, error);
            }
        }

    } catch (error) {
        console.error(error);
        m.reply('❌ حصل خطأ غير متوقع! حاول مرة أخرى لاحقًا.');
    }
};

handler.help = ['gifsticker <كلمة>', 'ملصق-متحرك <كلمة>'];
handler.command = ['gifsticker', 'ملصق-متحرك'];
handler.tags = ['sticker'];

export default handler;