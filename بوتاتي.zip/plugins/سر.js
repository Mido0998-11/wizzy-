const { areJidsSameUser, proto } = require('@whiskeysockets/baileys');
const { writeFileSync } = require('fs');

let inbox = {};

module.exports = {
  name: ['صندوق','سر','مجهول'].map(v => v + ' '),
  category: 'تواصل',
  desc: '💌 أرسل رسالة مجهولة لأي شخص في البوت.',
  use: '@منشن أو رد على الشخص',
  async exec(m, conn) {
    let target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return m.reply('📮 *منشن شخصًا أو رد على رسالته لإرسال رسالة مجهولة إليه.*');

    if (areJidsSameUser(target, m.sender)) return m.reply('🚫 لا يمكنك إرسال رسالة مجهولة لنفسك.');

    let msg = m.text.split(' ').slice(1).join(' ');
    if (!msg) return m.reply('📝 *يرجى كتابة الرسالة بعد الأمر.*');

    // إنشاء معرف مؤقت للردود
    let randomID = +new Date;
    inbox[randomID] = m.sender;

    await conn.sendMessage(target, {
      text: `╭──『 💠 *صندوق الأسرار* 』──⬣
│ 📨 *رسالة مجهولة وصلت لك!*
│ 
│ 💬 *الرسالة:* 
│ ${msg}
│ 
│ 🎭 *المرسل:* مجهول
╰─────────────────⬣`,
      contextInfo: {
        externalAdReply: {
          title: '💌 الرد على الرسالة المجهولة',
          body: 'COKU BOT | صندوق الأسرار',
          mediaUrl: '',
          mediaType: 1,
          thumbnailUrl: 'https://files.catbox.moe/83mwtm.jpg',
          renderLargerThumbnail: true,
          showAdAttribution: true
        }
      }
    }, {
      quoted: m,
      buttons: [
        { buttonId: `رد_${randomID}`, buttonText: { displayText: '💬 رد على المجهول' }, type: 1 },
        { buttonId: `حظر_المجهول_${randomID}`, buttonText: { displayText: '🚫 حظر الرسائل المجهولة' }, type: 1 },
      ],
    });

    m.reply('✅ *تم إرسال رسالتك المجهولة بنجاح.*');
  },

  async before(m, { conn, body }) {
    if (!body.startsWith('رد_')) return;

    let id = body.split('_')[1];
    if (!inbox[id]) return m.reply('❌ انتهت صلاحية هذه الرسالة.');

    let msg = m.text;
    let sender = inbox[id];
    await conn.sendMessage(sender, {
      text: `💌 *تم الرد على رسالتك المجهولة:*\n\n💬 ${msg}`,
    });

    m.reply('✅ *تم إرسال الرد إلى المرسل المجهول.*');
    delete inbox[id];
  }
};