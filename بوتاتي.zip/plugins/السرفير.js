import os from 'os';
import { sizeFormatter } from 'human-readable';
import pkg from '@whiskeysockets/baileys';

const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;
const formatSize = sizeFormatter({ std: 'JEDEC', decimalPlaces: 2 });

const handler = async (m, { conn }) => {
  const used = process.memoryUsage();
  const cpu = os.cpus()[0];
  const uptime = process.uptime() * 1000;
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  const platform = os.platform();
  const cpuCount = os.cpus().length;

  const info = `
╔═「 🛠️ حالة السيرفر 」
║ 🖥️ النظام: ${platform}
║ ⚙️ المعالج: ${cpu.model}
║ 🔢 الأنوية: ${cpuCount}
║ 💾 الذاكرة المستخدمة: ${formatSize(usedMem)} / ${formatSize(totalMem)}
║ ⏱️ مدة التشغيل: ${clockString(uptime)}
╚═══════════════════════
`.trim();

  const image = 'https://files.catbox.moe/pfnsj8.jpg';

  await conn.relayMessage(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: { title: `🔧 COKU BOT | السيرفر` },
          body: {
            text: info,
            subtitle: "🧩 أدوات السيرفر التكميلية"
          },
          header: {
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: image } }, { upload: conn.waUploadToServer }, { quoted: m }))
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔁 المساحة',
                  id: '.المساحة'
                })
              },
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: '📶 بنج',
                  id: '.بنج'
                })
              },
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: '👥 النشاط',
                  id: '.النشاط'
                })
              },
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: '🕒 مدة التشغيل',
                  id: '.المدة'
                })
              }
            ]
          }
        }
      }
    }
  }, {});
};

handler.help = ['السيرفر'];
handler.tags = ['info'];
handler.command = ['السيرفر'];

export default handler;

function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms % 3600000 / 60000);
  let s = Math.floor(ms % 60000 / 1000);
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}