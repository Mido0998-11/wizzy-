import { canLevelUp, xpRange } from '../lib/levelling.js'
import { levelup } from '../lib/canvas.js'

let handler = async (m, { conn, usedPrefix, command }) => {
  let { exp, limit, level, role } = global.db.data.users[m.sender]
  let { min, xp, max } = xpRange(level, global.multiplier)
  let name = conn.getName(m.sender)

  if (!canLevelUp(level, exp, global.multiplier)) {
    throw `
┏━━⬤『 ✦ لم ترتقِ بعد ✦ 』⬤━━┓

┃ ✦ الاسم: *${name}*
┃ ✦ المستوى: *${level}*
┃ ✦ التقدم: *${exp - min}/${xp}*
┃ ✦ الرتبة: *${role}*
┃ ✦ الخبرة: *${exp}*
┃ ✦ الماس: *${limit}*

┗━━⬤ تحتاج إلى *${max - exp}* نقطة للارتقاء. ⬤━━┛
`.trim()
  }

  let before = level
  while (canLevelUp(level, exp, global.multiplier)) level++
  global.db.data.users[m.sender].level = level

  if (before !== level) {
    let str = `
┏━━⬤『 🚀 مستوى جديد 🚀 』⬤━━┓

┃ ✦ الاسم: *${name}*
┃ ✦ السابق: *${before}*
┃ ✦ الحالي: *${level}*
┃ ✦ الرتبة: *${role}*

┗━━⬤ ⚔️ استمر بالارتقاء! ⬤━━┛
`.trim()

    try {
      let pp = await conn.profilePictureUrl(m.sender, 'image')
      await conn.sendMessage(m.chat, {
        image: { url: pp },
        caption: str,
        mentions: [m.sender],
        buttons: [
          {
            buttonId: `${usedPrefix}بروفايلي`,
            buttonText: { displayText: '👤 عرض بروفايلي' },
            type: 1,
          },
          {
            buttonId: `${usedPrefix}قسم-الالعاب`,
            buttonText: { displayText: '🎮 قسم الألعاب' },
            type: 1,
          }
        ],
        footer: '✨ COKU BOT - القوة في التحدي ✨'
      }, { quoted: m })
    } catch (e) {
      m.reply(str)
    }
  }
}

handler.help = ['levelup']
handler.tags = ['xp']
handler.command = ['رانك', 'lvl', 'لفل', 'level']
handler.group = true

export default handler