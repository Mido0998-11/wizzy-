import { createCanvas, loadImage } from 'canvas';

const backgroundUrl = 'https://s3.ezgif.com/tmp/ezgif-35348d7f0a1d4.jpg';

// دالة لحساب نسبة التقدم
function calcExpProgress(exp, level) {
    // نفترض مستوى لازم لكل level = level * 100 (يمكن تعديلها حسب نظامك)
    const expForLevel = level * 100;
    const expForPrevLevel = (level - 1) * 100;
    const currentExpInLevel = exp - expForPrevLevel;
    const totalExpForLevel = expForLevel - expForPrevLevel;
    return Math.min(Math.max(currentExpInLevel / totalExpForLevel, 0), 1);
}

const handler = async (m, { conn }) => {
    const user = global.db.data.users[m.sender];
    const name = conn.getName(m.sender);

    const oldLevel = user._lastLevel || 0;
    const currentLevel = user.level;
    const exp = user.exp || 0;
    const limit = user.limit || 0;

    if (currentLevel > oldLevel) {
        const image = await createLevelUpImage(name, currentLevel, exp, limit);
        await conn.sendMessage(m.chat, {
            image: image,
            caption: `🎉 مبروك يا ${name} لقد وصلت إلى المستوى ${currentLevel}!`,
        }, { quoted: m });
        user._lastLevel = currentLevel;
    }
};

async function createLevelUpImage(name, level, exp, limit) {
    const width = 720;
    const height = 720;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // الخلفية
    const background = await loadImage(backgroundUrl);
    ctx.drawImage(background, 0, 0, width, height);

    // إعدادات الخط
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.shadowColor = '#000';
    ctx.shadowBlur = 6;

    // الاسم
    ctx.font = 'bold 48px Arial';
    ctx.fillText(name, width / 2, 110);

    // المستوى
    ctx.font = 'bold 40px Arial';
    ctx.fillText(`المستوى ${level}`, width / 2, 180);

    // النقاط (EXP)
    ctx.font = '36px Arial';
    ctx.fillText(`نقاط الخبرة: ${exp}`, width / 2, 240);

    // الألماس
    ctx.fillText(`الألماس: ${limit}`, width / 2, 290);

    // شريط التقدم
    const progress = calcExpProgress(exp, level);
    const barWidth = 500;
    const barHeight = 30;
    const barX = (width - barWidth) / 2;
    const barY = 350;

    // خلفية الشريط
    ctx.fillStyle = '#444444';
    ctx.fillRect(barX, barY, barWidth, barHeight);

    // شريط التقدم
    ctx.fillStyle = '#FFD700'; // ذهبي
    ctx.fillRect(barX, barY, barWidth * progress, barHeight);

    // إطار الشريط
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.strokeRect(barX, barY, barWidth, barHeight);

    // نسبة التقدم
    ctx.font = '28px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${Math.floor(progress * 100)}%`, width / 2, barY + 25);

    return canvas.toBuffer();
}

export default handler;