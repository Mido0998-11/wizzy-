import fs from 'fs'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'

let handler = async (m, { conn, text, usedPrefix, __dirname }) => {
  try {
    let img = await (await fetch('https://files.catbox.moe/gd4d6r.jpg')).buffer()
    let d = new Date(new Date + 3600000)
    let locale = 'ar'
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
    let _uptime = process.uptime() * 1000
    let uptime = clockString(_uptime)
    let { exp, limit, level, role, money } = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let taguser = '@' + m.sender.split("@")[0]

    let str = `
╭────── •『 مرحباً بك 』•──────╮
│ ︙مرحباً ${taguser}
│ ︙اليـوم : ${week}
│ ︙التـاريخ : ${date}
│ ︙الـوقـت : ${uptime}
│ ︙الـمستوى : ${level}
│ ︙الـرتـبـة : ${role}
╰────── •『 𓆩★𓆪 』•──────╯

⌬『 قسـم الأعـضـاء 』⌬

⟡ .عمل
⟡ .طرد
⟡ .اقتباس
⟡ .عملاتي
⟡ .عملات
⟡ .توقيت
⟡ .بنك
⟡ .سحب
⟡ .ايداع
⟡ .محفظة
⟡ .تفعيل
⟡ .الغاء-التفعيل
⟡ .المشرفين
⟡ .بروفايل
⟡ .لفل
⟡ .خط
⟡ .توب
⟡ .يومي
⟡ .ترتيب

〞⌯┋توقيع المسؤول : مـيـدو
`.trim()

    await conn.sendMessage(m.chat, {
      image: img,
      caption: str,
      mentions: [m.sender],
    }, { quoted: m })

  } catch (e) {
    conn.reply(m.chat, '⚠️ حدث خطأ أثناء عرض القائمة', m)
  }
}

handler.command = /^(ق 1|قسم الاعضاء|ق1|ق_1)$/i
handler.exp = 20
handler.fail = null
export default handler

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}