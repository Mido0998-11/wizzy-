import pkg from '@whiskeysockets/baileys';
const { prepareWAMessageMedia } = pkg;

async function handler(m, { conn }) {
  let user = global.db.data.users[m.sender];
  if (!user) {
    global.db.data.users[m.sender] = { exp: 0, level: 1, limit: 10, role: 'مستخدم', premiumTime: 0 };
    user = global.db.data.users[m.sender];
  }

  // زيادة الخبرة تلقائيًا لكل رسالة
  user.exp = (user.exp || 0) + 10;

  // حساب الخبرة المطلوبة للترقية (مثلاً المستوى * 100)
  let expNeeded = user.level * 100;

  // تحقق لو وصل الحد الأقصى (مثلاً مستوى 1000)
  if (user.level >= 1000) {
    user.level = 1000; // لا يزيد عن 1000
    user.exp = 0; // لا تزيد الخبرة بعد ذلك
  } else {
    // إذا وصل للخبرة المطلوبة، يتم ترقية المستوى
    while (user.exp >= expNeeded && user.level < 1000) {
      user.exp -= expNeeded;
      user.level++;
      expNeeded = user.level * 100;
    }
  }

  // إرسال رسالة عند الترقية (أو يمكنك إرسال رسالة فقط في حالة الترقية - هنا مثال مبسط)
  if (user.exp < expNeeded) {
    const imageUrl = 'https://s3.ezgif.com/tmp/ezgif-35348d7f0a1d4.jpg';
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });
    await conn.sendMessage(m.chat, {
      image: media.image,
      caption: `🎉 مبروك ${conn.getName(m.sender)}!\nلقد ارتقيت إلى المستوى ${user.level} 🚀`,
      contextInfo: { mentionedJid: [m.sender] }
    });
  }
}