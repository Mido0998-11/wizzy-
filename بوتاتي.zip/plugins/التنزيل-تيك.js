import axios from 'axios';
import cheerio from 'cheerio';

const ttsave = {
  download: async (url) => {
    const apiUrl = 'https://ttsave.app/download';
    const headers = {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
      'Referer': 'https://ttsave.app/id'
    };
    const data = { query: url, language_id: "2" };
    try {
      const response = await axios.post(apiUrl, data, { headers });
      const html = response.data;
      return await ttsave.extract(html);
    } catch {
      return null;
    }
  },

  extract: async (html) => {
    const $ = cheerio.load(html);

    const username = $('div.mt-1.flex-col.justify-center.items-center h2').text().trim();
    const userHandle = $('div.mt-1.flex-col.justify-center.items-center a').first().text().trim();
    const avatar = $('img.w-16.h-16.rounded-full').attr('src');
    const description = $('p.oneliner').text().trim();

    return {
      username,
      userHandle,
      avatar,
      description,
      downloadLinks: {
        video: $('a[type="no-watermark"]').attr('href') || $('a[type="watermark"]').attr('href'),
        image: $('a[type="cover"]').attr('href'),
        audio: $('a[type="audio"]').attr('href')
      }
    };
  }
};

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('🔗 *أرسل رابط تيك توك لتحميل الفيديو*\n\nمثال: .تيك https://vt.tiktok.com/ZShYcGk31/');

  m.react('🎬');
  const res = await ttsave.download(text);
  if (!res || !res.downloadLinks.video) return m.reply('❌ *فشل التحميل، تحقق من الرابط*');

  const caption = `*⌯ 𝐓𝐈𝐊𝐓𝐎𝐊 - غوكو ⚡️*

• 👤 *الاسم:* ${res.username}
• 🆔 *المعرف:* ${res.userHandle}
• 📝 *الوصف:* ${res.description || 'بدون وصف'}

╰─⌯ الله يسعدك يأسطورة`;

  if (res.avatar) {
    await conn.sendMessage(m.chat, {
      image: { url: res.avatar },
      caption
    });
  }

  await conn.sendMessage(m.chat, {
    video: { url: res.downloadLinks.video },
    caption
  });

  if (res.downloadLinks.audio) {
    await conn.sendMessage(m.chat, {
      audio: { url: res.downloadLinks.audio },
      mimetype: 'audio/mp4'
    });
  }

  m.react('✅');
};

handler.help = ['tt', 'tiktok', 'ttdl', 'tiktokdl'];
handler.tags = ['التنزيل'];
handler.command = ['تيك', 'تيكك', 'تيكتوك', 'تيك'];

export default handler;