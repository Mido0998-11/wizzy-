const isLinkWa = /chat\.whatsapp\.com\/[A-Za-z0-9]{20,24}/i

export async function before(m, { conn, isAdmin, isBotAdmin }) {
  if (!m.isGroup) return false
  if (m.isBaileys) return false

  let chat = global.db.data.chats[m.chat]
  let bot = global.db.data.settings[this.user.jid] || {}
  const sender = m.sender
  const bang = m.key.id
  const delet = m.key.participant

  const isWhatsAppLink = isLinkWa.test(m.text)

  if (chat.antiWhatsApp && isWhatsAppLink) {
    if (!isBotAdmin) return m.reply(`❌ يجب أن أكون مشرفًا لحذف الرسائل أو طرد الأعضاء.`)
    if (!bot.restrict) return m.reply(`⚠️ هذا الأمر مخصص للمالك فقط. قم بتفعيل restrict.`)

    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
    await conn.reply(m.chat, `🚫 تم حذف رابط واتساب وتم طرد *@${sender.split('@')[0]}* من المجموعة.`, null, {
      mentions: [sender]
    })
    await conn.groupParticipantsUpdate(m.chat, [sender], 'remove')
  }

  return true
}