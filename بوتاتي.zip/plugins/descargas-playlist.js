import yts from 'yt-search';

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  const errorMsg = await tr("*¿Qué está buscando?* Ingrese el nombre del tema");
  const exampleMsg = await tr("Ejemplo");
  const noResults = await tr("No se encontraron resultados.");

  if (!text) return m.reply(`${errorMsg}\n*• ${exampleMsg}:*\n*${usedPrefix + command}* bad bunny`);
  m.react('📀');

  let result = await yts(text);
  let ytres = result.videos;
  if (!ytres.length) return m.reply(`❌ ${noResults}`);

  const resultsFor = await tr("Resultados de");
  const titleLabel = await tr("Título");
  const agoLabel = await tr("Publicado hace");
  const viewsLabel = await tr("Vistas");
  const durationLabel = await tr("Duración");
  const linkLabel = await tr("Enlace");

  // زخرفة غوكو
  const goku = '⎯͢⛧⏝͜͡𝐆𝐎𝐊𝐔͜⏝⛧⎯͢';

  if (m.isWABusiness) {
    let textoo = `*• ${resultsFor}:* ${text}\n\n`;
    for (let i = 0; i < Math.min(15, ytres.length); i++) {
      let v = ytres[i];
      textoo += `🎵 *${titleLabel}:* ${v.title}\n📆 *${agoLabel}:* ${v.ago}\n👀 *${viewsLabel}:* ${v.views}\n⌛ *${durationLabel}:* ${v.timestamp}\n🔗 *${linkLabel}:* ${v.url}\n\n⊱ ────── {.⋅ ♫ ⋅.} ───── ⊰\n\n`;
    }
    await conn.sendFile(m.chat, ytres[0].image, 'thumbnail.jpg', textoo, m);
  } else {
    const sections = [{
      title: `🎶 ${resultsFor}: ${text}`,
      rows: ytres.slice(0, 10).map(v => ({
        title: v.title,
        description: `${durationLabel}: ${v.timestamp} | ${viewsLabel}: ${v.views}\n───────────────\n🎬 .ytmp4 ${v.url}\n🎵 .ytmp3 ${v.url}`,
        rowId: `.ytmp4 ${v.url}`
      }))
    }];

    await conn.sendMessage(m.chat, {
      text: `📊 *${resultsFor}:* ${text}`,
      footer: `🤖 بوت ${goku} — اختر المقطع من القائمة`,
      title: `📥 نتائج البحث بواسطة ${goku}`,
      buttonText: '🎬 عرض النتائج',
      sections,
      image: { url: ytres[0].image }
    }, { quoted: m });
  }
};

handler.help = ['playlist', 'yts'];
handler.tags = ['downloader'];
handler.command = ['playvid2', 'بحث', 'playlista', 'yts', 'ytsearch'];
handler.register = true;

export default handler;