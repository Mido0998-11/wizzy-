import fetch from 'node-fetch';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    return m.reply(`╭─〔 *أمر الحلم* 〕─╮\n│ ✨ *مثال:* ${usedPrefix + command} مدينة ليلاً | Cyberpunk\n╰──────────────╯`);
  }

  let fullPrompt = args.join(" ").split("|");
  let prompt = fullPrompt[0]?.trim();
  let style = fullPrompt[1]?.trim() || "Cyberpunk";

  let apiUrl = `https://www.takamura.site/api/ai/deepimg?prompt=${encodeURIComponent(prompt)}&style=${encodeURIComponent(style)}`;

  await m.reply(`╭─〔 *جاري الحلم...* 〕─╮\n│ ⏳ *الوصف:* ${prompt}\n│ 🎨 *النمط:* ${style}\n╰──────────────╯`);

  try {
    let res = await fetch(apiUrl);
    let json = await res.json();

    if (!json?.url) throw new Error("الرابط غير صالح أو لا يحتوي على صورة.");

    let imageUrl = json.url;

    let sent = await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: `╭─〔 *تم الحلم* 〕─╮\n│ ✨ *الوصف:* ${prompt}\n│ 🎨 *النمط:* ${style}\n│ ❤️ *الله يرزقك راحة البال والسعادة.*\n╰──────────────╯`
    }, { quoted: m });

    // تفاعل بالإيموجي
    if (sent?.key) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "🌙",
          key: sent.key,
        }
      });
    }

  } catch (e) {
    console.log(e)
    m.reply("❌ حدث خطأ أثناء الحلم بالصورة. حاول مجددًا.");
  }
};

handler.command = ['حلم'];
export default handler;