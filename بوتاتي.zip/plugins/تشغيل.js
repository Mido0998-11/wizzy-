import { prepareWAMessageMedia, generateWAMessageFromContent, getDevice } from '@whiskeysockets/baileys';
import yts from 'yt-search';
import fs from 'fs';

const handler = async (m, { conn, text, usedPrefix: prefijo }) => {
    const device = await getDevice(m.key.id);

    if (!text) return conn.reply(m.chat, '⚠️ أدخل اسم الأغنية التي تريد البحث عنها ⚠️', m);

    if (device !== 'desktop' && device !== 'web') {
        const results = await yts(text);
        const videos = results.videos.slice(0, 20);
        const randomIndex = Math.floor(Math.random() * videos.length);
        const randomVideo = videos[randomIndex];

        const messa = await prepareWAMessageMedia({ image: { url: randomVideo.thumbnail }}, { upload: conn.waUploadToServer });
        const interactiveMessage = {
            body: {
                text: `📥 تشغيل من يوتيوب\n\n» *العنوان:* ${randomVideo.title}\n» *المدة:* ${randomVideo.duration.timestamp}\n» *الناشر:* ${randomVideo.author.name || 'غير معروف'}\n» *منذ:* ${randomVideo.ago}\n» *الرابط:* ${randomVideo.url}\n`
            },
            footer: { text: `${global.dev}`.trim() },
            header: {
                title: ``,
                hasMediaAttachment: true,
                imageMessage: messa.imageMessage,
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: 'خيارات التحميل',
                            sections: videos.map((video) => ({
                                title: video.title,
                                rows: [
                                    { header: video.title, title: video.author.name, description: 'تحميل MP3 (صوت)', id: `${prefijo}ytmp3 ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'تحميل MP4 (فيديو)', id: `${prefijo}ytmp4 ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'MP3 كملف', id: `${prefijo}ytmp3doc ${video.url}` },
                                    { header: video.title, title: video.author.name, description: 'MP4 كملف', id: `${prefijo}ytmp4doc ${video.url}` }
                                ]
                            }))
                        })
                    }
                ],
                messageParamsJson: ''
            }
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage,
                },
            },
        }, { userJid: conn.user.jid, quoted: null });
        conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } else {
        const idioma = global.db.data.users[m.sender].language;
        const _translate = JSON.parse(fs.readFileSync(`./language/${idioma}.json`));
        const traductor = _translate.plugins.buscador_yts;
        const results = await yts(text);
        const tes = results.all;
        const teks = results.all.map((v) => {
            if (v.type === 'video') return `
° *_${v.title}_*
↳ 🔗 *_الرابط :_* ${v.url}
↳ ⏱️ *_المدة :_* ${v.timestamp}
↳ 🗓️ *_منذ :_* ${v.ago}
↳ 👁️ *_المشاهدات :_* ${v.views}`;
        }).filter(v => v).join('\n\n────────────────────\n\n');
        conn.sendFile(m.chat, tes[0].thumbnail, 'thumbnail.jpg', teks.trim(), m);
    }
};

handler.help = ['تشغيل *<اسم الأغنية>*'];
handler.tags = ['تحميل'];
handler.command = ['تشغيل'];
handler.register = true;

export default handler;