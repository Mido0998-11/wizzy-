import fetch from 'node-fetch';

let toM = a => '@' + a.split('@')[0];

async function handler(m, { conn, groupMetadata }) {
    let participants = groupMetadata.participants.map(v => v.id);
    let a = participants[Math.floor(Math.random() * participants.length)];
    let b;
    do {
        b = participants[Math.floor(Math.random() * participants.length)];
    } while (b === a);

    const imageUrl = 'https://telegra.ph/file/ecc5e1dde8b541a33519f.jpg';

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: `
🔥🔥 يا جماعة، دقّت ساعة الانتقام!

*❯😤╎الضحية:* ${toM(a)}
*❯💔╎المظلومة:* ${toM(b)}

${toM(a)} طلقها بالتلاتة لو عندك دم!!
${toM(b)} متقلقيش، هنجوزك سيد سيدو!

> خليك دايمًا تضحك، الحياة قصيرة جدًا يا صاحبي 🍹😂
        `.trim(),
        mentions: [a, b]
    }, { quoted: m });
}

handler.help = ['formarpareja'];
handler.tags = ['main', 'fun'];
handler.command = ['طلقني', 'طلاق'];
handler.group = true;

export default handler;