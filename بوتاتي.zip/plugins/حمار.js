import axios from 'axios';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `❗ أرسل سؤالك أو طلبك للذكاء الاصطناعي.\n\nمثال:\n*${usedPrefix + command} ما هو الذكاء الاصطناعي؟*`;

  const prompt = args.join(" ");
  await m.react("🤖");

  try {
    const res = await axios.get(`https://aigc-api.deno.dev/gpt?text=${encodeURIComponent(prompt)}`);
    const response = res.data.reply;

    await conn.sendMessage(m.chat, {
      text: `╭──⭓  *🤖 COKU AI*\n│\n*✪ سؤالك:* ${prompt}\n\n*✪ الإجابة:* ${response}\n╰───────⭑`,
    }, { quoted: m });

    await m.react("✅");
  } catch (err) {
    console.error(err);
    await m.reply("❌ حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.");
  }
};

handler.help = ['حمار <سؤال>'];
handler.tags = ['حمار'];
handler.command = ['حمار', 'goku', 'ai'];
handler.limit = false;

export default handler;