import fetch from 'node-fetch';
import fs from 'fs';

let handler = async (m, { conn, usedPrefix, args, command, text }) => {
  if (!text) throw `*❐ اكـتـب الأمـر + رابـط فـيـديـو أو ريـلز من إنـسـتـغـرام*\n\n*◐ مثـال :*\n*.انستا* https://www.instagram.com/reel/C4BZLtmrQPm/?igsh=cmplZHR6NjJhNjc5`;

  await m.react('🕖');

  try {
    let mediaURL = await zack(text);
    if (!mediaURL) throw new Error('*❌ لـم يـتـم الـعـثـور عـلـى رابـط الـفـيـديـو*');

    await conn.sendFile(m.chat, mediaURL, '', `*⌯ 𝐇𝐈𝐆𝐇 𝐐𝐔𝐀𝐋𝐈𝐓𝐘 - إنـسـتـا 🎥*

• تم تحميل الفيديو بنجاح!

> *⟪ COKU • B͠O͠T ⟫*`, m, false, { mimetype: 'video/mp4' });

  } catch (error) {
    console.error('✘ خطأ أثناء التحميل:\n', error);
    throw `*⚠️ حــدث خــطـأ أثــنـاء تـحـمـيـل الـفـيـديـو*\n${error.message}`;
  }
};

async function zack(text) {
  try {
    let res = await fetch(`https://bk9.fun/download/instagram?url=${encodeURIComponent(text)}`);
    if (!res.ok) throw new Error('*⚠️ فشل في الاتصال بـ API*');

    let json = await res.json();
    if (!json.status || !json.BK9[0]?.url) throw new Error('*❌ لم يتم العثور على رابط الفيديو*');

    const fileName = 'Instagram_video.mp4';
    const fileStream = fs.createWriteStream(fileName);

    let videoRes = await fetch(json.BK9[0].url);
    if (!videoRes.ok) throw new Error('*⚠️ فشل تحميل الفيديو من المصدر*');

    videoRes.body.pipe(fileStream);

    await new Promise((resolve, reject) => {
      fileStream.on('finish', resolve);
      fileStream.on('error', reject);
    });

    return fileName;
  } catch (error) {
    console.error('✘ فشل أثناء التحميل:\n', error);
    return false;
  }
}

handler.help = ['انستا'];
handler.tags = ['التنزيل'];
handler.command = /^(انستجرام|ig|انستا|انستغرام)$/i;

export default handler;