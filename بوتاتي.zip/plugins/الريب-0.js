let handler = m => m;

handler.all = async function (m) {
    let responses;

    if (/^تست$/i.test(m.text)) {
        responses = ['*شـغـال يـسـطـا 🧚‍♀️*'];
    } else if (/^بوت$/i.test(m.text)) {
        responses = ['*اسـمـي غـوكـو يـسـطـا 😒*'];
    } else if (/^غوكو$/i.test(m.text)) {
        responses = ['*مـعـاك ي قـلـبـي 🧚‍♀️*'];
    } else if (/^هاي$/i.test(m.text)) {
        responses = ['*هـاي ي بـيبي*', '*هـاي ي قـمـري*'];
    } else if (/^سلام$/i.test(m.text)) {
        responses = ['*وعـلـيكم الـسـلام و رحـمـة الله 🕊️*'];
    } else if (/^عامل ايه$/i.test(m.text)) {
        responses = ['*كـلـو زي الـفل يـسـطـا، انـت عامـل ايه؟*'];
    } else if (/^احبك$/i.test(m.text)) {
        responses = ['*وانـا أكـثـر يـروح غـوكـو*'];
    } else if (/^غبي$/i.test(m.text)) {
        responses = ['*احـتـرم نـفـسـك يـسـطـا، غـوكـو مـش لـلـغـبـاء*'];
    } else if (/^نعم$/i.test(m.text)) {
        responses = ['*نـعـم ي قـلـبـي، امـر؟*'];
    } else if (/^(تنصيب|code)$/i.test(m.text)) {
        responses = ['*تم قفل التنصيب ولم يتم فتحها مرة أخرى لأن تفاعلكم ميت في قناة البوت  *'];
    } else if (/^وينك$/i.test(m.text)) {
        responses = ['*هنا معاك، ما بتبعدش يـسـطـا*', '*غوكو دايمًا موجود ليك*'];
    } else if (/^تصبح على خير$/i.test(m.text)) {
        responses = ['*تصبح على نور يا غالي*', '*نوم هنيئ يا قلبي*'];
    } else if (/^شكرًا$/i.test(m.text)) {
        responses = ['*عفواً يا وردة*', '*في الخدمة دايمًا*'];
    } else if (/^انت حلو$/i.test(m.text)) {
        responses = ['*وأنت أحلى يا زول*', '*الكلام ده بيدخل القلب*'];
    } else if (/^احبك كتير$/i.test(m.text)) {
        responses = ['*وانا أكتر، حبك بيدفيني*'];
    } else if (/^ازايك$/i.test(m.text)) {
        responses = ['*تمام وبخير، ان شاء الله انت كمان*'];
    } else if (/^عايز اتكلم معاك$/i.test(m.text)) {
        responses = ['*أنا هنا لأي كلام تحبه*', '*قول يا زول*'];
    }

    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);
        conn.reply(m.chat, responses[randomIndex], m);
    }

    return !0;
};

export default handler;