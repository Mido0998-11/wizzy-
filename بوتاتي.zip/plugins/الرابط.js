// الكود الخاص بأمر "الروابط"
const handler = async (m, { conn, args, usedPrefix, command }) => {
  const chat = global.db.data.chats[m.chat] || {}

  const sections = [
    {
      title: "🛡️ خيارات الحظر",
      rows: [
        {
          title: `رابط TikTok ${chat.antiTiktok ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط tiktok`
        },
        {
          title: `رابط YouTube ${chat.antiYoutube ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط youtube`
        },
        {
          title: `رابط Telegram ${chat.antiTelegram ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط telegram`
        },
        {
          title: `رابط Facebook ${chat.antiFacebook ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط facebook`
        },
        {
          title: `رابط Instagram ${chat.antiInstagram ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط instagram`
        },
        {
          title: `رابط Twitter ${chat.antiTwitter ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط twitter`
        },
        {
          title: `رابط واتساب ${chat.antiWhatsapp ? '✅ مفعل' : '❌ معطل'}`,
          rowId: `${usedPrefix}تبديل_رابط whatsapp`
        }
      ]
    }
  ]

  await conn.sendMessage(m.chat, {
    text: `*📵 نظام منع الروابط:*\n\nقم بتفعيل أو تعطيل أي نوع من الروابط في المجموعة.`,
    footer: 'اختر من القائمة بالأسفل:',
    title: '🚫 منع الروابط',
    buttonText: 'اختيار النوع',
    sections
  }, { quoted: m })
}

handler.command = /^الروابط$/i
handler.group = true
handler.admin = true
handler.botAdmin = true
export default handler