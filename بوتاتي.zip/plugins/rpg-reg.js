import { createHash } from 'crypto'

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i

let handler = async function (m, { conn, text, usedPrefix, command }) {
  let user = global.db.data.users[m.sender]
  let name2 = conn.getName(m.sender)

  if (user.registered === true) throw `
┏━━⬣ *🚨 تنبيه من غوكو*
┃ ✳️ *أنت بالفعل مسجل يا بطل!*
┃
┃ ⚔️ *لو عايز تمسح تسجيلك:*
┃ ✦ *${usedPrefix}حذف-التسجيل <الرقم التعريفي>*
┗⬣ *اختر بحكمة أيها المحارب!*
`

  if (!Reg.test(text)) throw `
┏━━⬣ *❌ خطأ في التسجيل*
┃
┃ 🧾 *الصيغة الصحيحة يا بطل:*
┃ ✦ *${usedPrefix + command} الاسم.العمر*
┃
┃ 🌀 *مثال:* 
┃ ✦ *${usedPrefix + command}* ${name2}.17
┃
┃ ⚠️ *جرب مرة تانية بأسلوب صحيح!*
┗⬣ *غوكو دايمًا معاك!*
`

  let [_, name, splitter, age] = text.match(Reg)

  if (!name) throw '🚫 *غوكو يقول:* الاسم فاضي يا أسطورة!'
  if (!age) throw '🚫 *غوكو يقول:* العمر لازم يتكتب يا بطل!'
  if (name.length >= 30) throw '⚠️ *غوكو يقول:* اسمك طويل كأنك بتكتب رواية! 😅'

  age = parseInt(age)
  if (age > 50) throw '👴🏻 *غوكو مستغرب!* جدو؟ بتلعب معانا؟ 😂'
  if (age < 10) throw '👶🏻 *غوكو يقول:* ارجع كمل لبن 🍼 يا صغير!'

  // التسجيل
  user.name = name.trim()
  user.age = age
  user.regTime = +new Date
  user.registered = true

  // إعدادات البروفايل الافتراضية
  user.biodata ??= "غير محدد"
  user.exp ??= 0
  user.level ??= 1
  user.rank ??= "💫 مبتدئ Saiyan"
  user.msgs ??= 0
  user.usage ??= 0

  // الرقم التعريفي
  let sn = createHash('md5').update(m.sender).digest('hex')
  let date = new Date(user.regTime).toLocaleString('ar-EG', { dateStyle: 'full', timeStyle: 'short' })

  // جلب صورة البروفايل
  let profilePic
  try {
    profilePic = await conn.profilePictureUrl(m.sender, 'image')
  } catch {
    profilePic = 'https://telegra.ph/file/265c672094dfa87caea19.jpg' // صورة افتراضية
  }

  let caption = `
╭━━━〔 ⚡ *تسجيل Saiyan* ⚡ 〕━━⬣
┃
┃ 🧑‍🚀 *الاسم:* 『 ${user.name} 』
┃ 🎂 *العمر:* 『 ${user.age} سنة 』
┃ 🆔 *الرقم التعريفي:* 
┃ ${sn}
┃
┃ 💬 *عدد الرسائل:* ${user.msgs}
┃ 🧪 *الأوامر المستخدمة:* ${user.usage}
┃ 🎖️ *الرتبة:* ${user.rank}
┃ 📝 *البايو:* ${user.biodata}
┃ ⏱️ *التسجيل:* ${date}
┃
┃ ✅ *تم تسجيلك بنجاح*
┃ 🚀 *انطلق الآن مع غوكو نحو المعارك الأسطورية!*
╰━━━━━━━━━━━━━━⬣
`.trim()

  await conn.sendFile(m.chat, profilePic, 'profile.jpg', caption, m)
}

handler.help = ['تسجيل <الاسم.العمر>']
handler.tags = ['rg']
handler.command = ['تسجيل']

export default handler