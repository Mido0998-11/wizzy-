import fs from 'fs';
import path from 'path';

let handler = async (m, { conn }) => {
    const folderPath = './plugins/';

    fs.readdir(folderPath, (err, files) => {
        if (err) return m.reply('`حـدث خـطـا اثـنـاء قـرائـة الـمـجـلـد`');

        let renamedFiles = [];

        files.forEach(file => {
            const oldPath = path.join(folderPath, file);
            const newFileName = file.replace(/\s+/g, '-');
            const newPath = path.join(folderPath, newFileName);

            if (oldPath !== newPath) {
                fs.rename(oldPath, newPath, err => {
                    if (!err) renamedFiles.push(`*◐ ${file} ➜ ${newFileName}*`);
                });
            }
        });

        setTimeout(() => {
            if (renamedFiles.length > 0) {
                m.reply(`*تم تعديل أسماء الملفات :*\n\n> | ${renamedFiles.join('\n> | ')}`);
            } else {
                m.reply('`مـفـيـش مـلـفـات مـحـتـاجـة تـعـديـل` 🧚');
            }
        }, 1000);
    });
};

handler.command = ['مسافه', 'مسافة'];
handler.help = ['مسافة'];
handler.tags = ['الادوات'];
handler.owner = true; 
handler.rowner = true;  

export default handler;