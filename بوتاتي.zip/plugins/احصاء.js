import { generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys';

let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل فقط داخل المجموعات');

  let groupMetadata = await conn.groupMetadata(m.chat);
  let participants = groupMetadata.participants;

  let countryCount = {};
  for (let user of participants) {
    let number = user.id.split('@')[0];
    let code = number.match(/^\d{1,4}/)?.[0] || 'غير معروف';
    countryCount[code] = (countryCount[code] || 0) + 1;
  }

  let sorted = Object.entries(countryCount).sort((a, b) => b[1] - a[1]);

  let output = `⌯┋تم فحص الأرقام بدقة ...\n\n📊 ⊰ 𓆩 إحصاء الأرقام حسب الدولة 𓆪 ⊱\n\n`;
  for (let [code, count] of sorted) {
    output += `⟣ ⪼ +${code} ⟿ *${toArabic(count)}* رقم\n`;
  }
  output += `\n⟬🧮 تم إيجاد *${toArabic(participants.length)}* رقم في المجموعـة⟭\n`;
  output += `\n⊱━━❪ 𓆩⚡𝐂𝐎𝐊𝐔 𝐁𝐎𝐓⚡𓆪 ❫━━⊰`;

  const interactiveMessage = {
    body: { text: '🧮 تم تحليل الأرقام!\nاختر ما تريد:' },
    footer: { text: '⌯ بواسطة COKU BOT ⚡' },
    nativeFlowMessage: {
      buttons: [
        {
          name: 'cta_copy',
          buttonParamsJson: JSON.stringify({
            display_text: '📋 نسخ الإحصاء',
            copy_code: output
          })
        },
        {
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: '🔐 إرسال الإحصاء إلى الخاص',
            id: '.ارسال_الاحصاء'
          })
        }
      ],
      messageParamsJson: ''
    }
  };

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage
      }
    }
  }, { userJid: conn.user.jid, quoted: m });

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  // خزن الإحصاء لإرساله لاحقًا لو طلب المستخدم
  global.lastStat = global.lastStat || {};
  global.lastStat[m.sender] = output;
};

// الأمر الذي يرسل الإحصاء إلى الخاص
let privateStatHandler = async (m, { conn }) => {
  if (!global.lastStat || !global.lastStat[m.sender]) {
    return m.reply('❌ لا يوجد إحصاء محفوظ لك. استخدم الأمر داخل القروب أولًا.');
  }
  await conn.sendMessage(m.sender, { text: global.lastStat[m.sender] }, { quoted: m });
};

function toArabic(number) {
  const map = {
    '0': '𝟢', '1': '𝟣', '2': '𝟤', '3': '𝟥', '4': '𝟦',
    '5': '𝟧', '6': '𝟨', '7': '𝟩', '8': '𝟪', '9': '𝟫'
  };
  return number.toString().split('').map(d => map[d] || d).join('');
}

handler.help = ['احصاء_الدول'];
handler.tags = ['group'];
handler.command = ['احصاء_الدول', 'countcountries'];
export default handler;

// الأمر الإضافي لزر الإرسال للخاص
let handler2 = {
  command: ['ارسال_الاحصاء'],
  tags: [],
  help: [],
  async handler(m, args) {
    return privateStatHandler(m, this);
  }
};

export { handler2 as additionalHandler };