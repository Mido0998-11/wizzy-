let handler = async (m, { conn }) => {

conn.sendMessage(
    m.chat,
    {
      image: {
        url: "https://i.postimg.cc/mkN39qmS/1743934625027.jpg",
      },
      caption: `*اسمع الكلام واقفل بقا يعرص 😂*`,
      fileLength: "999",
      viewOnce: true,
    },
    {
      quoted: m,
    },
  );
};
 
handler.help = ['ping']
handler.tags = ['main']
handler.command = ['واحده']

export default handler;