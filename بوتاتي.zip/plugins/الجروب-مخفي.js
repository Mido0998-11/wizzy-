import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

let handler = async (m, { conn, text, participants, isAdmin, command }) => {
    if (!isAdmin) return m.reply('🚫 هذا الأمر للمشرفين فقط!')

    if (!text) return m.reply(`✳️ أرسل رسالة مثل:\n.${command} مرحبًا بالجميع!`);

    let fakegif = { 
        key: { 
            participant: `0@s.whatsapp.net`, 
            ...(m.chat ? { remoteJid: m.chat } : {}) 
        }, 
        message: { 
            videoMessage: { 
                title: '𓆩⚡𝐂𝐎𝐊𝐔 𝐁𝐎𝐓⚡𓆪', 
                h: `Hmm`, 
                seconds: '99999', 
                gifPlayback: true, 
                caption: 'COKU BOT', 
                jpegThumbnail: false 
            } 
        } 
    };

    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid);

    // زخرفة رسالة غوكو بوت
    const decoratedText = 
`╔═══❪ 𓆩⚡𝐂𝐎𝐊𝐔 𝐁𝐎𝐓⚡𓆪 ❫═══╗
╟ ⎝⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏝
╟ 📢 الرسالة من: @${m.sender.split('@')[0]}
╟
╟ ✨ ${text}
╟
╟ ⎠⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏤⏞
╚════════════════════╝
⚡ 𝙂𝙤𝙠𝙪 𝘽𝙤𝙩 𝙗𝙮 𝙈𝙤𝙝𝙖𝙢𝙢𝙚𝙙 𝘼𝙙𝙚𝙡 ⚡`;

    let msg = generateWAMessageFromContent(m.chat, {
        extendedTextMessage: {
            text: decoratedText,
            contextInfo: {
                mentionedJid: users
            }
        }
    }, {
        userJid: conn.user.id,
        quoted: fakegif
    });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ['hidetag'];
handler.tags = ['group'];
handler.command = /^(hidetag|مخفي|اخفي)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = false;

export default handler;