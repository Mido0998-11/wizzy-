const handler = async (m, { conn, text, command, usedPrefix }) => {
  const pp = './src/warn.jpg';
  let who;
  if (m.isGroup) 
    who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text;
  else 
    who = m.chat;

  const user = global.db.data.users[who];
  const bot = global.db.data.settings[conn.user.jid] || {};
  const warntext = `*اعـمـل مـنـشـن او رد عـلـي شـخـص*`;
  
  if (!who) throw m.reply(warntext, m.chat, { mentions: conn.parseMention(warntext) });
  if (m.mentionedJid.includes(conn.user.jid)) return;

  if (user.warn == 0) throw `هـوا نـضـيـف مـش عـلـيـة اي تـحـذيـرات 🍧🦆`;

  user.warn -= 1;

  const replyText = user.warn == 1 
    ? `*━━━══━━【✵】━━══━━━*\n*تم ازالة تحذير عن @${who.split`@`[0]}*\n> *عدد التحذيرات دلوقت : ${user.warn}/3*\n*━━━══━━【✵】━━══━━━*`
    : `*━━━══━━【✵】━━══━━━*\n*تمت إزالة التحذير لـ* @${who.split`@`[0]}❫\n> *عدد التحذيرات دلوقت : ${user.warn}/3*\n*━━━══━━【✵】━━══━━━*`;

  await m.reply(replyText, null, { mentions: [who] });
  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
};
handler.command = /^(حذف-الانذار|الغاء-الانذار|حذف-التحذير|الغاء-التحذير|delwarning|الغاء_الانذار|الغاءالانذار)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;