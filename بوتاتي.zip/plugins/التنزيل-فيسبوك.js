import fetch from 'node-fetch';

const handler = async (m, { conn, args, command, usedPrefix }) => {
  if (!args[0]) {
    throw `╭──⌈ *غـوكـو ⚡️* ⌋
│❯ *مطلوب رابط الفيديو*
│❯ مثال: ${usedPrefix + command} https://www.facebook.com/watch?v=123
╰───◇`;
  }

  if (!args[0].match(/www.facebook.com|fb.watch/g)) {
    throw `╭──⌈ *غـوكـو ⚡️* ⌋
│❯ *الرابط غير صالح لفيسبوك*
│❯ مثال: ${usedPrefix + command} https://www.facebook.com/watch?v=123
╰───◇`;
  }

  m.react(`⌛`);

  try {
    const apiUrl = `https://api.siputzx.my.id/api/d/facebook?url=${encodeURIComponent(args[0])}`;
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (!data.status || !data.data || data.data.length === 0)
      throw new Error('فشل جلب بيانات الفيديو.');

    const videoOptions = data.data;
    const description = data.desc || 'بدون وصف';
    const duration = data.duration || 'غير محدد';

    const hd = videoOptions.find(v => v.resolution.toLowerCase().includes('hd'));
    const sd = videoOptions.find(v => v.resolution.toLowerCase().includes('sd'));
    const selected = hd || sd || videoOptions[0];

    const resolutionName = selected.resolution || 'غير معروف';
    const videoSize = selected.size || 'غير متوفر';

    // رابط مختصر
    const shortUrlRes = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(selected.url)}`);
    const shortUrl = await shortUrlRes.text();

    await conn.sendFile(
      m.chat,
      selected.url,
      'facebook_video.mp4',
      `╭──⌈ *معلومـات الفيديو* ⌋
│❯ *الوصف:* ${description}
│❯ *الجودة:* ${resolutionName}
│❯ *المدة:* ${duration}
│❯ *الحجم:* ${videoSize}
│❯ *الرابط:* ${shortUrl}
╰──⌈ *غـوكـو ⚡️* ⌋`,
      m
    );

    m.react(`✅`);
  } catch (error) {
    console.error('Facebook Error:', error);
    m.react(`❌`);
    m.reply(`❌ فشل تحميل الفيديو. تأكد من الرابط أو حاول لاحقًا.`);
  }
};

handler.help = ['facebook', 'fb', 'فيسبوك'];
handler.tags = ['downloader'];
handler.command = /^(facebook|fb|فيسبوك|فيس)$/i;
handler.limit = 0;
handler.register = true;

export default handler;