import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `✧︙اكتب سؤالك بعد الأمر\n❐ ┇مثال: ${usedPrefix}${command} من هو شانكس؟`, m);

  try {
    let res = await fetch(`https://www.takamura.site/api/ai/gpt/shanks?text=${encodeURIComponent(text)}`);
    let json = await res.json();
    let replyText = json?.result || '✖︙لم يتم الحصول على رد.';

    await conn.reply(m.chat, `╭─❖ *شـانكـس الذكـي*\n┃✧︙سؤالك: ${text}\n┃✧︙الرد: ${replyText}\n╰─❖`, m);
  } catch (e) {
    await conn.reply(m.chat, '✖︙حدث خطأ في الاتصال بذكاء شانكس، حاول لاحقًا.', m);
  }
};

handler.command = ['شانكس'];
handler.help = ['شانكس'];
handler.tags = ['ai'];
handler.premium = false;
handler.limit = false;

export default handler;