let totalCommandsUsed = 0;
const userCommandCounts = {};

const handler = async (m, { conn, participants }) => {
  totalCommandsUsed++;

  const sender = m.sender;
  if (!userCommandCounts[sender]) userCommandCounts[sender] = 0;
  userCommandCounts[sender]++;

  const sortedUsers = Object.entries(userCommandCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([user, count], i) => ` ${i + 1}. @${user.split('@')[0]} » *${count}*`);

  const hours = new Date().getHours();
  let peakTime = '🌙 ليلًا';
  if (hours >= 6 && hours < 12) peakTime = '🌞 صباحًا';
  else if (hours >= 12 && hours < 18) peakTime = '🌤️ ظهرًا';
  else if (hours >= 18 && hours < 24) peakTime = '🌙 مساءً';

  const text = `
╔═「 📊 تحليل النشاط 」
║ 📌 عدد الأوامر: *${totalCommandsUsed}*
║ 👑 أكثر المستخدمين تفاعلًا:
${sortedUsers.join('\n') || ' لا يوجد بعد'}
║ 🕐 وقت الذروة الحالي: ${peakTime}
╚═══════════════════════
`.trim();

  conn.sendMessage(m.chat, {
    text,
    mentions: sortedUsers.map(([user]) => user)
  }, { quoted: m });
};

handler.help = ['النشاط'];
handler.tags = ['info'];
handler.command = ['النشاط'];

export default handler;