let handler = async (m, { conn, args, command }) => {
await m.reply('`جــود بـــاي` 🙂') 
await  conn.groupLeave(m.chat)}
handler.command = /^(out|طير|اخرج|برا)$/i
handler.group = true
handler.rowner = true
export default handler