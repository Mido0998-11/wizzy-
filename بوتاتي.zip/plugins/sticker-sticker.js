import { sticker } from '../lib/sticker.js'
import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'
import { webp2png } from '../lib/webp2mp4.js'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender]
  let stiker = false
  let [packnameArg, authorArg] = args.join(" ").split("|")

  // تخصيص اسم الحزمة والمؤلف
  let f = packnameArg?.trim() || user.packname || global.packname
  let g = authorArg?.trim() || user.author || global.author

  await m.react('🧩') // التفاعل الأولي

  try {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    if (/webp|image|video/g.test(mime)) {
      if (/video/g.test(mime)) {
        if ((q.msg || q).seconds > 18) return m.reply('⚠️ الفيديو طويل! الرجاء استخدام فيديو أقل من 12 ثانية 🕐')
      }

      let img = await q.download?.()
      if (!img) return m.reply(`🌟 *فين الصورة؟*\n\n↳ رد على صورة أو فيديو قصير لصنع الملصق ✨\n\n❖ مثال: *${usedPrefix + command}*`)

      let out
      try {
        await m.reply('⌛ *جـــاري إنــشاء الملـــصق لـك...* 🧩\n\n╰━═❖✨ *صبرًا يا بطل!*')
        stiker = await sticker(img, false, f, g)
      } catch (e) {
        console.error(e)
      } finally {
        if (!stiker) {
          if (/webp/g.test(mime)) out = await webp2png(img)
          else if (/image/g.test(mime)) out = await uploadImage(img)
          else if (/video/g.test(mime)) out = await uploadFile(img)
          if (typeof out !== 'string') out = await uploadImage(img)
          stiker = await sticker(false, out, f, g)
        }
      }
    } else if (args[0]) {
      if (isUrl(args[0])) stiker = await sticker(false, args[0], f, g)
      else return m.reply('❌ الرابط غير صالح! تأكد من أنه ينتهي بـ jpg أو png أو gif')
    }
  } catch (e) {
    console.error(e)
    if (!stiker) stiker = e
  } finally {
    if (stiker) {
      await m.react('✅')
      conn.sendFile(m.chat, stiker, 'sticker.webp', '', m, true, {
        contextInfo: {
          forwardingScore: 200,
          isForwarded: false,
          externalAdReply: {
            showAdAttribution: false,
            title: "GOKU BOT - ملصقات",
            body: `✨ تم إنشاء الملصق بنجاح!`,
            mediaType: 2,
            sourceUrl: [nna, nn, md, yt].getRandom(),
            thumbnail: imagen4
          }
        }
      }, { quoted: m })
    } else {
      await m.react('❌')
      return m.reply(`🌟 *فين الصورة؟*\n\n↳ رد على صورة أو فيديو قصير لصنع الملصق ✨\n\n❖ مثال: *${usedPrefix + command}*`)
    }
  }
}

handler.help = ['s', 'ملصق']
handler.tags = ['sticker']
handler.command = ['s', 'sticker', 'ملصق']
handler.register = true

export default handler

const isUrl = (text) => {
  return text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)(jpe?g|gif|png)/, 'gi'))
}