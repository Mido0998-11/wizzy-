import fs from 'fs'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'
import { promises } from 'fs'
import { join } from 'path'

let handler = async (m, { conn, usedPrefix, __dirname, text }) => {
try {
let pp = 'https://files.catbox.moe/gd4d6r.jpg'
let img = await (await fetch(pp)).buffer()
let d = new Date(new Date + 3600000)
let locale = 'ar'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
let _uptime = process.uptime() * 1000
let uptime = clockString(_uptime)

let user = global.db.data.users[m.sender]
let { exp, limit, level, role, money, joincount } = user
let { min, xp, max } = xpRange(level, global.multiplier)

let taguser = '@' + m.sender.split("@s.whatsapp.net")[0]
let str = `
╭─❐ *قسم المطور - COKU:* ❐─╮
│ 🛠️ ⎔ .بريم
│ 🛠️ ⎔ .الغاء-البريم
│ 🛠️ ⎔ .بان
│ 🛠️ ⎔ .الغاء_البان
│ 🛠️ ⎔ .رفع-الحظر
│ 🛠️ ⎔ .حظر
│ 🛠️ ⎔ .المبندين
│ 🛠️ ⎔ .إعادة
│ 🛠️ ⎔ .ريستارت
│ 🛠️ ⎔ .ادخل
│ 🛠️ ⎔ .ضيف_اكس_بي
│ 🛠️ ⎔ .ضيف_جواهر
╰───────────────╯

*توقيع:* COKU × 𝗪𝗶𝘇𝘇𝗬
`.trim()

let buttonMessage = {
  image: { url: pp },
  caption: str,
  mentions: [m.sender],
  footer: '',
  headerType: 4
}

conn.sendMessage(m.chat, buttonMessage, { quoted: m })

} catch {
  conn.reply(m.chat, '[❗خطاء❗]', m)
}
}

handler.command = /^(قسم-المطور|قسم المطور|ق3|ق_3)$/i
handler.exp = 20
handler.fail = null
export default handler

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}