import { googleImage } from '@bochilteam/scraper';

const handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`✿ اكتب اسم أنمي أو شخصية\nمثال:\n.${command} Naruto`);

  const bannedWords = ['sex', 'porn', 'سكس', 'هنتاي', 'نيك', 'pussy', 'porno', 'xnxx', 'xvideos', 'هوت', 'مايا خليفه'];
  if (bannedWords.some(word => text.toLowerCase().includes(word))) {
    return m.reply('✿ استغفر ربك!');
  }

  try {
    const results = await googleImage(text + ' anime');
    const shuffled = results.sort(() => 0.5 - Math.random()).slice(0, 10); // نحصل على 10 صور عشوائية

    await m.reply(`✿ تم العثور على *${shuffled.length}* صورة أنمي لكلمة: *${text}*\n\n⌯ من تطوير 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧`);

    for (let url of shuffled) {
      await conn.sendFile(m.chat, url, 'anime.jpg', `╭─❖ 「 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 」❖─
│ ✿ صورة أنمي: *${text}*
╰──────────────`, m);
      await new Promise(res => setTimeout(res, 1500)); // تأخير بين الصور
    }

    await conn.sendMessage(m.chat, {
      text: `▣ دعاء اليوم:
اللهم اجعل هذا اليوم خيرًا وسعادةً ورضًا لكل من يستخدم البوت.

⌯ 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 - الأفضل دائماً.`,
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply(`✿ حدث خطأ أثناء جلب الصور\n⌯ 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧`);
  }
};

handler.command = ['صور-انمي', 'animepic'];
handler.help = ['صور-انمي <كلمة>'];
handler.tags = ['anime'];

export default handler;