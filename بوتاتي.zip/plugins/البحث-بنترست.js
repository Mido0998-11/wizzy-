import axios from 'axios';
import { pinterest } from '../lib/scraper.js';
import baileys from '@whiskeysockets/baileys';

const { generateWAMessageContent, generateWAMessageFromContent, proto } = baileys;

let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) throw `𓆩⚠️𓆪 أدخـل كلمـة بحـث ⚡\n\n🎯 مثـال: *${usedPrefix + command} انمي بنات*`;

    await m.react("📸");
    conn.reply(m.chat, '⌯ *📥 جـاري جلب أفضـل الصـور...*', m);

    async function createImageMessage(url) {
        const { imageMessage } = await generateWAMessageContent(
            { image: { url } },
            { upload: conn.waUploadToServer }
        );
        return imageMessage;
    }

    const sources = [
        async () => {
            const response = await pinterest.search(text, 30);
            return response.result.pins.map(pin => pin.media.images.orig.url);
        },
        async () => {
            const res = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}`);
            return res.data.data.map(result => result.images_url);
        },
        async () => {
            const res = await axios.get(`https://api.dorratz.com/v2/pinterest?q=${encodeURIComponent(text)}`);
            return res.data.map(result => result.image);
        }
    ];

    let images = [];
    for (const source of sources) {
        try {
            images = await source();
            if (images.length > 0) break;
        } catch (e) {
            console.error(`⚠️ خطأ أثناء البحث: ${e.message}`);
        }
    }

    if (images.length === 0) {
        await m.react("❌");
        return m.reply(`❌ لم يتم العثور على نتائج لـ *"${text}"*.`);
    }

    // اختيار 20 صورة عشوائية
    const shuffled = images.sort(() => 0.5 - Math.random()).slice(0, 20);

    let imagesList = [];
    let counter = 1;

    for (let imageUrl of shuffled) {
        imagesList.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `📸 *صـورة رقم:* ${counter++}\n⌯ 𓆩 ${text} 𓆪`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                imageMessage: await createImageMessage(imageUrl)
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        "display_text": "🌐 زور قناتـنا",
                        "url": "https://whatsapp.com/channel/0029VaLzXkm9yXPmWbNloR0l"
                    })
                }]
            })
        });
    }

    const finalMessage = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: "𓆩🔎 نـتـائـج بحـثـك 𓆪\n⌯ تقديـم : 𓆩COKU𓆪 الـعـالـمـي"
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: imagesList
                    })
                })
            }
        }
    }, { quoted: m });

    await m.react("✅");
    await conn.relayMessage(m.chat, finalMessage.message, { messageId: finalMessage.key.id });
};

handler.help = ['pinterest <الكلمة>'];
handler.tags = ['بحث'];
handler.command = /^(pin|بين)$/i;
handler.register = true;
handler.limit = 0;

export default handler;