import { existsSync, promises as fs } from 'fs'
import path from 'path'
import moment from 'moment-timezone'

var handler = async (m, { conn }) => {
  if (global.conn.user.jid !== conn.user.jid) {
    return conn.reply(m.chat, '🚫 *هذا الأمر مخصص للرقم الرئيسي للبوت فقط!*', m)
  }

  // التاريخ بالتنسيق العربي
  const date = moment().tz('Africa/Khartoum').format('📅 يوم ddd، D MMMM YYYY\n🕓 الساعة HH:mm')
  const mention = [m.sender]

  await conn.sendMessage(m.chat, { text: `🔄 *جارٍ تنظيف ملفات الجلسة المؤقتة...*\n\n⌛ *الرجاء الانتظار قليلًا...*`, mentions: mention }, { quoted: m })

  let sessionPath = './BotSession/'
  try {
    if (!existsSync(sessionPath)) {
      return await conn.reply(m.chat, '📂 *المجلد غير موجود!*\n✳️ تأكد من أن المسار صحيح.', m)
    }

    let files = await fs.readdir(sessionPath)
    let filesDeleted = 0

    for (const file of files) {
      if (file !== 'creds.json') {
        await fs.unlink(path.join(sessionPath, file))
        filesDeleted++
      }
    }

    if (filesDeleted === 0) {
      await conn.reply(m.chat, '✅ *لا توجد ملفات للحذف (creds.json فقط محفوظ)*', m)
    } else {
      await conn.sendMessage(m.chat, {
        text: `✅ *تم حذف عدد ${filesDeleted} ملفاً بنجاح!*\n\n📁 *الملف المحفوظ:* creds.json\n\n📌 *المنفذ:* @${m.sender.split('@')[0]}\n${date}`,
        mentions: mention
      }, { quoted: m })

      await conn.reply(m.chat, '🧹 *تم التنظيف بنجاح، يا مدير!* ✨', m)
      await conn.reply(m.chat, '👾 *غوكو بوت تحت أمرك يا نجم!* 💠', m)
    }
  } catch (err) {
    console.error('❌ خطأ أثناء الحذف:', err)
    await conn.reply(m.chat, '⚠️ *حدث خطأ أثناء تنفيذ العملية! حاول لاحقًا.*', m)
  }
}

handler.help = ['نظف']
handler.tags = ['owner']
handler.command = /^(نظف)$/i
handler.rowner = true

export default handler