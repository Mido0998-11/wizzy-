import axios from 'axios';

let handler = async (m, { text }) => {
    if (!text) {
        return m.reply(
`┏━〔 *ڤــان الذكــي* 〕━┓
┃  
┃ ✦ هل نسيت تكتب شيء؟  
┃ ✦ ڤان ما بيقرأ العقول  
┃ ✦ اكتبلي شي أفصفصو ليك  
┃  
┗━━━━━━━━━━━━┛`);
    }

    const aiName = 'ڤان';

    let apiUrl = `https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug?text=رد بأسلوب ساخر ذكي فقط، بدون لهجة، واسمك ڤان، كن لاذع لو احتاج الأمر: ${encodeURIComponent(text)}&country=Global&user_id=VAN_INTEL`;

    try {
        let res = await axios.get(apiUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Referer': 'https://www.ai4chat.co/pages/youtube-comment-generator'
            }
        });

        let replyText = res.data?.comment || res.data || '…ڤان مشغول بالتأمل، جرّب تاني.';

        await m.reply(
`┏〔 *رد ڤــان* 〕┓

${replyText}

┗━━━━━━━━━━┛`);
    } catch (err) {
        console.error(err);
        await m.reply('*⚠️ حدث خطأ، ڤان مش فاضي لك الآن. حاول لاحقًا.*');
    }
};

handler.help = ['ڤان'];
handler.tags = ['ai'];
handler.command = /^ڤان$/i;
handler.limit = false;

export default handler;