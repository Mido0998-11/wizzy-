let handler = async (m, { conn }) => {
  if (global.conn.user.jid === conn.user.jid) {
    // إذا كان البوت الأساسي
    await m.reply(`⚠️ لا يمكن إيقاف البوت الرئيسي بهذا الأمر، هذا مخصص للبوتات الفرعية فقط.`);
  } else {
    // إذا كان بوت فرعي
    await conn.reply(m.chat, `✅ *تم إيقاف البوت الفرعي بنجاح.*\n✨ شكرًا لاستخدامك *COKU BOT*`, m);
    await conn.ws.close();
  }
};

handler.help = ['إيقاف البوت الفرعي'];
handler.tags = ['بوت'];
handler.command = ['توقف', 'اطفاء', 'وقف'];
handler.owner = true;

export default handler;