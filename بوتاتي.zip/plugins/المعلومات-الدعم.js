let handler = async m => m.reply(`

≡  *هـيـكـس - بـوت*

_GROUP:_
─────────────
*▢ انضم إلى مجموعة البوت*
ـ https://chat.whatsapp.com/Dc1haEb1VZdGtOnviarVRc

─────────────`.trim())
handler.help = ['gpguru']
handler.tags = ['main']
handler.command = ['group', 'support','الدعم','دعم']

export default handler