import { createHash } from 'crypto'

let handler = async function (m, { conn }) {
  let user = global.db.data.users[m.sender]
  if (!user.registered) throw `❌ لم تقم بالتسجيل بعد!\n\n📝 استخدم: *تسجيل اسمك.عمرك*`

  // إنشاء الرقم التعريفي المختصر
  let sn = createHash('md5').update(m.sender).digest('hex').slice(0, 8)

  // إعادة ضبط بيانات المستخدم
  user.name = ''
  user.age = 0
  user.regTime = 0
  user.registered = false
  user.exp = 0
  user.money = 0
  user.limit = 0
  user.premium = false

  await m.reply(`
╭─❖ 「 *تم حذف التسجيل* 」❖─
│ ✘ تم إلغاء تسجيلك بنجاح
│ 
│ 🆔 رقمك التعريفي السابق: *${sn}*
│ 
│ يمكنك التسجيل من جديد باستخدام:
│ *تسجيل اسمك.عمرك*
╰───────────────
  `.trim())
}

handler.help = ['حذف-التسجيل']
handler.tags = ['rg']
handler.command = ['حذف-التسجيل', 'unregister', 'الغاء-التسجيل']

export default handler