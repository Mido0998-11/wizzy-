let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `✶ يرجى إدخال الرقم أو المعرف:\n➥ ${usedPrefix + command} 212XXXXXXXXX 10`;

  let jid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  let newLimit = parseInt(args[1]);

  if (isNaN(newLimit) || newLimit < 1) throw '✶ أدخل رقمًا صالحًا للحد (1 فأكثر).';

  let user = global.db.data.users[jid];
  if (!user) throw '✶ المستخدم غير موجود في قاعدة البيانات.';

  user.apkDownloads = user.apkDownloads || { count: 0, lastDay: 0, limit: 2 };
  user.apkDownloads.limit = newLimit;

  m.reply(`✅ تم تعيين حد تحميل التطبيقات لـ ${jid} إلى: ${newLimit} تطبيق يوميًا.`);
};

handler.command = ['رفع_حد_التطبيقات'];
handler.help = ['رفع_حد_التطبيقات <رقم> <عدد>'];
handler.tags = ['owner'];
handler.rowner = true;
export default handler;