const { cmd } = require('../command');
const config = require("../config");

// نظام منع الكلمات السيئة
cmd({
  'on': "body"
}, async (conn, m, store, {
  from,
  body,
  isGroup,
  isAdmins,
  isBotAdmins,
  reply,
  sender
}) => {
  try {
    // قائمة الكلمات السيئة الممنوعة
    const كلمات_سيئة = ["wtf", "mia", "xxx", "fuck", 'sex', "huththa", "pakaya", 'ponnaya', "hutto"];

    // إذا لم تكن الرسالة في مجموعة، أو المرسل أدمن، أو البوت ليس أدمن، لا يتم التنفيذ
    if (!isGroup || isAdmins || !isBotAdmins) {
      return;
    }

    // تحويل النص إلى حروف صغيرة للمقارنة
    const نص_الرسالة = body.toLowerCase();

    // التحقق إذا كانت الرسالة تحتوي على كلمة سيئة
    const يوجد_كلمة_سيئة = كلمات_سيئة.some(كلمة => نص_الرسالة.includes(كلمة));

    if (يوجد_كلمة_سيئة && config.ANTI_BAD_WORD === "true") {
      // حذف الرسالة المخالفة
      await conn.sendMessage(from, { 'delete': m.key }, { 'quoted': m });
      // إرسال تحذير في المجموعة
      await conn.sendMessage(from, { 'text': "🚫 ⚠️ لا يسمح بالكلمات السيئة ⚠️ 🚫" }, { 'quoted': m });
    }
  } catch (error) {
    console.error(error);
    reply("حدث خطأ أثناء معالجة الرسالة.");
  }
});

// نظام منع الروابط
const نماذج_الروابط = [
  /https?:\/\/(?:chat\.whatsapp\.com|wa\.me)\/\S+/gi,
  /^https?:\/\/(www\.)?whatsapp\.com\/channel\/([a-zA-Z0-9_-]+)$/,
  /wa\.me\/\S+/gi,
  /https?:\/\/(?:t\.me|telegram\.me)\/\S+/gi,
  /https?:\/\/(?:www\.)?youtube\.com\/\S+/gi,
  /https?:\/\/youtu\.be\/\S+/gi,
  /https?:\/\/(?:www\.)?facebook\.com\/\S+/gi,
  /https?:\/\/fb\.me\/\S+/gi,
  /https?:\/\/(?:www\.)?instagram\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?twitter\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?tiktok\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?linkedin\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?snapchat\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?pinterest\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?reddit\.com\/\S+/gi,
  /https?:\/\/ngl\/\S+/gi,
  /https?:\/\/(?:www\.)?discord\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?twitch\.tv\/\S+/gi,
  /https?:\/\/(?:www\.)?vimeo\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?dailymotion\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?medium\.com\/\S+/gi
];

cmd({
  'on': "body"
}, async (conn, m, store, {
  from,
  body,
  sender,
  isGroup,
  isAdmins,
  isBotAdmins,
  reply
}) => {
  try {
    // شرط مشابه لنظام الكلمات السيئة
    if (!isGroup || isAdmins || !isBotAdmins) {
      return;
    }

    // التحقق إذا كانت الرسالة تحتوي على أي رابط من النماذج
    const يوجد_رابط = نماذج_الروابط.some(نمط => نمط.test(body));

    if (يوجد_رابط && config.ANTI_LINK === 'true') {
      // حذف الرسالة التي تحتوي على الرابط
      await conn.sendMessage(from, { 'delete': m.key }, { 'quoted': m });

      // إرسال رسالة تحذير وذكر المرسل في المجموعة
      await conn.sendMessage(from, {
        'text': `⚠️ الروابط غير مسموحة في هذه المجموعة.\n@${sender.split('@')[0]} تم طردك من المجموعة. 🚫`,
        'mentions': [sender]
      }, { 'quoted': m });

      // طرد المرسل من المجموعة
      await conn.groupParticipantsUpdate(from, [sender], "remove");
    }
  } catch (error) {
    console.error(error);
    reply("حدث خطأ أثناء معالجة الرسالة.");
  }
});