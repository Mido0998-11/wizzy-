export async function before(m, { conn }) {
    const emojis = ['🍧', '🗿', '💋', '🦆', '🌷', '💜', '☘️', '💘', '🍄', '🍨', '👾'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    try {
        return await conn.newsletterReactMessage(
            m.key.remoteJid,
            m.newsletterServerId.low.toString(),
            randomEmoji
        );
    } catch (e) {
        console.error('ايرر :', e);
    }
}