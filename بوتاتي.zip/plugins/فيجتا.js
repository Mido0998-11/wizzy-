import axios from 'axios';

let handler = async (m, { conn, text }) => {
    if (!text) {
        return m.reply(
`╔═⟪ *فيجيتا | أمير الساياجين* ⟫═╗

😒 وين الكلام؟ ما تخليني أضيع وقتي على الفاضي!

╚════════════════╝`);
        return;
    }

    const aiName = 'فيجيتا';
    const apiUrl = `https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug?text=رد بأسلوب فيجيتا، أضف إيموجيات مناسبة مثل 😏🔥💢😤 واستخدم نبرة حادة لكن ذكية، لا تخرج عن الشخصية: ${encodeURIComponent(text)}&country=PlanetVegeta&user_id=VEGETA_AI_2025`;

    // إظهار "يكتب..."
    await conn.sendPresenceUpdate('composing', m.chat);

    try {
        const res = await axios.get(apiUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Referer': 'https://www.ai4chat.co/pages/youtube-comment-generator'
            }
        });

        const response = res.data?.comment || res.data || '...أنا لا أضيع وقتي على هذا الهراء 💢';

        await m.reply(
`💢 *فيجيتا يرد عليك:*

${response}

⚠️ *لا تستهين بأمير الساياجين... 😤*`);
    } catch (err) {
        console.error(err);
        await m.reply('❌ حتى فيجيتا لا يستطيع فهم هذا الخطأ الآن...');
    }
};

handler.help = ['فيجيتا'];
handler.tags = ['ai'];
handler.command = /^فيجيتا$/i;
handler.limit = false;

export default handler;