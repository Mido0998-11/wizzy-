import fs from 'fs';

let handler = async (m, { conn }) => {
  if (!m.isGroup) return;

  let metadata = await conn.groupMetadata(m.chat);
  let isClosed = metadata.announce;

  let button = isClosed
    ? { buttonId: 'room_open', buttonText: { displayText: '⏋🔓︱ افــــتـــح ︱🔓⎿' }, type: 1 }
    : { buttonId: 'room_close', buttonText: { displayText: '⏋🔒︱ اقــــفــــل ︱🔒⎿' }, type: 1 };

  await conn.sendMessage(m.chat, {
    text: isClosed ? '`︱    الـجـروب مـقـفـول    ︱`\n\n> `اضـغـط عـلـي الـزر لـلـفـتـح` 🧁 ' : '`︱    الـجـروب مـفـتـوح    ︱`  \n\n> `اضـغـط عـلـي الـزر لـلـقـفـل` 🧁',
    buttons: [button],
    footer: '',
    headerType: 1
  });
};

handler.command = ['جروب'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;

global.roomControlHandler = async function (conn, msg) {
  if (!msg.message?.buttonsResponseMessage || msg.key.fromMe) return;

  let buttonId = msg.message.buttonsResponseMessage.selectedButtonId;
  let chat = msg.key.remoteJid;

  if (buttonId === 'room_close') {
    await conn.groupSettingUpdate(chat, 'announcement');
  }

  if (buttonId === 'room_open') {
    await conn.groupSettingUpdate(chat, 'not_announcement');
  }
};

if (!global.roomControlHandlerAttached) {
  global.roomControlHandlerAttached = true;
  conn.ev.on('messages.upsert', async ({ messages }) => {
    try {
      let msg = messages[0];
      await global.roomControlHandler(conn, msg);
    } catch (e) {
      console.error('Error in room button:', e);
    }
  });
}