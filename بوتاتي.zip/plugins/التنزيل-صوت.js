import yts from "yt-search";
import axios from "axios";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`🎵 *يرجى إدخال عنوان الأغنية أو رابط يوتيوب!*\n\n🔹 *مثال:* ${usedPrefix + command} صوت عصام صاصا`);

  await m.react('🕓');

  const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/|v\/)|youtu\.be\/)([\w\-]+)/;
  const match = text.match(youtubeRegex);

  let videoInfo;
  if (match) {
    const results = await yts({ videoId: match[1] });
    if (!results) return m.reply("❌ *لم يتم العثور على الفيديو.*");
    videoInfo = results;
  } else {
    const searchResults = await yts(text);
    if (!searchResults.videos.length) return m.reply("❌ *لم يتم العثور على الأغنية.*");
    videoInfo = searchResults.videos[0];
  }

  const url = videoInfo.url;
  const title = videoInfo.title;

  const caption = `
╭── ⭓ 𓆩 🖤 𝐂𝐎𝐊𝐔 𝐁𝐎𝐓 🖤 𓆪
│ ✪ *الاسم:* ${videoInfo.title}
│ ✪ *القناة:* ${videoInfo.author.name}
│ ✪ *المشاهدات:* ${videoInfo.views.toLocaleString()}
│ ✪ *المدة:* ${videoInfo.timestamp}
│ ✪ *تاريخ النشر:* ${videoInfo.ago}
╰── 🕊️ *اللهم اجعل هذا العمل خالصاً لوجهك الكريم*
  `.trim();

  // أرسل الصورة والمعلومات أولاً
  await conn.sendMessage(m.chat, {
    image: { url: videoInfo.image },
    caption: caption
  }, { quoted: m });

  // تحميل الصوت
  try {
    const audioRes = await axios.get(`https://api.vevioz.com/api/button/mp3/${videoInfo.videoId}`, { responseType: 'json' });
    const audioUrl = audioRes.data.url[0].url;

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mp4',
      fileName: `${title}.mp3`
    }, { quoted: m });
  } catch (e) {
    await m.reply("❌ *فشل تحميل الصوت.*");
  }

  // تحميل الفيديو
  try {
    const videoRes = await axios.get(`https://api.vevioz.com/api/button/mp4/${videoInfo.videoId}`, { responseType: 'json' });
    const videoUrl = videoRes.data.url[0].url;

    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: `🎥 *${title}*`
    }, { quoted: m });
  } catch (e) {
    await m.reply("❌ *فشل تحميل الفيديو.*");
  }

  await m.react('✅');
};

handler.help = ["صوت <رابط أو عنوان>"];
handler.tags = ["downloader"];
handler.command = /^(صوت)$/i;
handler.register = true;

export default handler;