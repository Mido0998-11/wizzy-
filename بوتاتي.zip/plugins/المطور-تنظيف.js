let handler = async (m, { conn }) => {
  let txt = '`اخــتــر الــمــهــمــةة :`';

  const buttons = [
    { buttonId: '.نظف', buttonText: { displayText: '⏋🧁︱ تــنـظـيـف الــسـيـسـون ︱🧁⎿' }, type: 1 },
    { buttonId: '.dchat', buttonText: { displayText: '⏋🍨︱ تــنـظـيـف الــمـحـادثــة ︱🍨⎿' }, type: 1 },
  ];

  await conn.sendMessage(m.chat, {
    text: txt,
    footer: '♯ 𝐇 Ꭵ 𝐗 • 𝐁❍𝐓 ⚡',
    buttons: buttons,
    headerType: 1
  }, { quoted: m });
};

handler.command = /^تنظيف$/i;
export default handler;