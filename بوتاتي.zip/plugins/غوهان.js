import axios from 'axios';

let handler = async (m, { conn, text }) => {
    if (!text) {
        return m.reply(
`╭━━〔 *غوهان | إبن غوكو* 〕━━╮
│  
│ ⚠️ نسيت تكتب سؤالك؟  
│ ✦ أنا غوهان، ابن غوكو  
│ ✦ أقدر أساعدك في أي شيء  
│  
╰━━━━━━━━━━━━━━━━╯`);
    }

    const aiName = 'غوهان';
    let apiUrl = `https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug?text=رد بأسلوب غوهان ابن غوكو، محترم، وذكي، لكن إظهر قوتك لو أحد سخر من والدك: ${encodeURIComponent(text)}&country=Namek&user_id=GOHAN_POWER`;

    // إظهار أن غوهان يكتب
    await conn.sendPresenceUpdate('composing', m.chat);

    try {
        let res = await axios.get(apiUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Referer': 'https://www.ai4chat.co/pages/youtube-comment-generator'
            }
        });

        let replyText = res.data?.comment || res.data || '...غوهان الآن يتدرب، جرّب لاحقًا.';

        await m.reply(
`╭─〔 *رد غوهان* 〕─╮

${replyText}

╰──────────────╯`);
    } catch (err) {
        console.error(err);
        await m.reply('*⚠️ حصل خطأ من غوهان، أعد المحاولة بعد قليل.*');
    }
};

handler.help = ['غوهان'];
handler.tags = ['ai'];
handler.command = /^غوهان$/i;
handler.limit = false;

export default handler;