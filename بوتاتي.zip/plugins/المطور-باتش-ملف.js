import fs from 'fs';
import path from 'path';

let handler = async (m, { conn }) => {
  // تحقق من أن الرسالة هي رد على رسالة تحتوي على نص مسار الملف
  if (!m.quoted || !m.quoted.text) {
    return m.reply('❌ من فضلك قم بالرد على رسالة تحتوي على مسار الملف المطلوب.');
  }

  let filePath = m.quoted.text.trim();

  // تحقق من أن المسار يبدأ بـ ./ أو /
  if (!filePath.startsWith('./') && !filePath.startsWith('/')) {
    return m.reply('❌ المسار غير صحيح. يجب أن يبدأ بـ ./ أو /');
  }

  filePath = path.resolve(filePath);

  // تحقق من وجود الملف في المسار المحدد
  if (!fs.existsSync(filePath)) {
    return m.reply('❌ الملف غير موجود في هذا المسار.');
  }

  let content;
  try {
    content = fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return m.reply('⚠️ حدث خطأ أثناء قراءة الملف.');
  }

  // إرسال المحتوى كنص
  await conn.sendMessage(m.chat, {
    text: `${content.substring(0, 999999999)}`,
    contextInfo: {
      externalAdReply: { 
title: '♯ 𝐇 Ꭵ 𝐗 • 𝐁❍𝐓 🦇',
        body: 'مـن تـطـويـر ويـسـكـي ي عـزيـزي 🐤🍧🥢',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/a185i6.jpg',
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });

  // إرسال الملف كمرفق
  await conn.sendMessage(m.chat, {
    document: fs.readFileSync(filePath),
    fileName: path.basename(filePath),
    mimetype: 'text/plain'
  }, { quoted: m });
};

handler.command = /^ملف/i; 
handler.owner = true;
export default handler;