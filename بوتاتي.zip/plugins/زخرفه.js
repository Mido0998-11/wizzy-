import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  try {
    // فصل الكلمات
    let words = text.trim().split(' ');

    // الكلمة الأولى = المفتاح، والباقي هو النص
    let key = parseInt(words[0]);
    let textToStyle = words.slice(1).join(' ');

    // لو ما فيش مفتاح ولا نص → عرض كل الأشكال لنص افتراضي
    if (!text || !key || !textToStyle) {
      const defaultText = 'ƚᥲᖇხ᥆᥆_ხ᥆ƚ';
      const styledTexts = await Promise.all(
        [...Array(34).keys()].map(i => stylizeText(defaultText, i + 1))
      );
      const replyText = styledTexts.join('\n\n📍 ');
      return conn.reply(m.chat, `📌 *زخرفة "${defaultText}":*\n\n📍 ${replyText}`, m);
    }

    // تحقق من صحة المفتاح
    if (isNaN(key) || key < 1 || key > 34) {
      return conn.reply(m.chat, '🚫︙*المفتاح يجب أن يكون رقمًا بين 1 و 34.*', m);
    }

    // الزخرفة الفردية
    const styled = await stylizeText(textToStyle, key);
    conn.reply(m.chat, `✅ *الزخرفة رقم ${key}:*\n\n${styled}`, m);

  } catch (err) {
    console.error(err);
    conn.reply(m.chat, '❌︙حدث خطأ أثناء الزخرفة. حاول مجددًا.', m);
  }
};

handler.help = ['زخرفه <رقم> <نص>'];
handler.tags = ['tools'];
handler.command = /^(زخرفه|زغرفه)$/i;
handler.exp = 0;
export default handler;

async function stylizeText(text, key) {
  const api = `https://inrl-web-fkns.onrender.com/api/fancy?text=${encodeURIComponent(text)}&key=${key}`;
  const res = await fetch(api);
  if (!res.ok) throw new Error('API Error');
  const json = await res.json();
  return json.result || '❗ لا توجد نتيجة.';
}