import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
  try {
    let pp = 'https://files.catbox.moe/dno3x7.jpg'
    let img = await (await fetch(pp)).buffer()
    let taguser = '@' + m.sender.split("@")[0]

    let text = `
╭━━〔 ⚠️ قسم الـدعـم ⚠️ 〕━━╮
┃ مرحباً بك ${taguser}
┃ تـواصـل مع فريق البوت أو المطـور
┃ للإبلاغ عن مشكلة أو طلب ميزة
┃━━━━━━━━━━━━━━
┃ 🛠️ .ابلاغ  ← للإبلاغ عن خطأ
┃ ☎️ .دعم     ← طلب المساعدة
┃ 👨‍💻 .المطور ← معلومات المطور
┃ ❓ .اقتراح   ← اقتراح ميزة جديدة
┃ ⚙️ .تحديث   ← تحديث البوت
┃ 💡 .معلومة   ← معلومة مفيدة
╰━━━━━━━━━━━━━━╯

⌯ 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 ⌯
⌯ 𝗪𝗶𝘇𝘇𝗬 المطـور ⌯
`.trim()

    await conn.sendMessage(m.chat, {
      image: img,
      caption: text,
      mentions: [m.sender],
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          mediaType: 1,
          showAdAttribution: false,
          thumbnail: img
        }
      }
    }, { quoted: m })

  } catch (e) {
    conn.reply(m.chat, '⚠️ حدث خطأ، حاول لاحقاً.', m)
  }
}

handler.command = /^(ق8|قسم-الدعم|ق_8)$/i
handler.exp = 20
export default handler