import fetch from 'node-fetch';

const apiKey = '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'; // 🔒 لا تنشره أبدًا!

let handler = async (m, { text, conn, args, command }) => { if (!text) return m.reply('❗ اكتب سؤالك بعد الأمر مثل: \nذكاء ما هو الذكاء الاصطناعي؟');

try { let res = await fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', headers: { 'Authorization': Bearer ${apiKey}, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: text }], temperature: 0.7 }) });

let json = await res.json();
if (!json?.choices || !json.choices[0]?.message?.content)
  throw '⚠️ لم أتمكن من الحصول على رد، حاول مرة أخرى';

let replyText = json.choices[0].message.content.trim();
let name = m.pushName || 'مستخدم';

await conn.sendMessage(m.chat, {
  text: `╭─❖「 *ذَڪــاء غوكو 🤖* 」❖\n│ 💬 *سؤالك:* ${text}\n╰───◆\n\n${replyText}\n\n✨ *تم الرد بواسطة الذكاء الاصطناعي*`,
  contextInfo: {
    externalAdReply: {
      title: "غوكو بوت",
      body: `رد ذكي لك يا ${name} 💬`,
      thumbnailUrl: 'https://files.catbox.moe/83mwtm.jpg',
      sourceUrl: 'https://chat.openai.com/',
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
}, { quoted: m });

} catch (err) { console.error(err); m.reply('❌ حصل خطأ أثناء التواصل مع الذكاء الاصطناعي'); } };

handler.help = ['ذكاء', 'ذ']; handler.tags = ['ai']; handler.command = /^(ذكاء|ظوذ)$/i; handler.premium = false; // إذا أردته فقط للبريميوم عدله export default handler;

