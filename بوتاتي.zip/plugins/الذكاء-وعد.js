import axios from 'axios';
let handler = async (m, {
    text
}) => {
    if (!text) {
        return m.reply('*▩ اهلا بك انا هي وعد مساعدة الذكاء الاصطناعي ماذا تحتاج اليوم 🍧*');
    }
    const shyo = 'وعد' // nama ai

    let anu = `https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug?text=اتكلمي باللهجة المصريه يا وعد مترديش ب اي لغة تانيه ${encodeURIComponent(text)}&country=Asia&user_id=M08wTiyb56`;

    try {
        let res = await axios.get(anu, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://www.ai4chat.co/pages/youtube-comment-generator'
            }
        });

        if (res.data) {
            let generatedComment = res.data.comment || res.data;
            await m.reply(`${generatedComment}`);
        } else {
            await m.reply(`Gagal! bot ${shyo} tak merespon`);
        }
    } catch (error) {
        console.error(error);
        await m.reply(`ايرور ${shyo} error`);
    }
};

handler.help = ['وعد'];
handler.tags = ['الذكاء'];
handler.command = /^وعد$/i;
handler.limit = false;

export default handler;