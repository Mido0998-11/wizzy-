function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms % 3600000 / 60000);
    let s = Math.floor(ms % 60000 / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

const handler = async (m, { conn, usedPrefix, __dirname, text, isPrems }) => {
    let d = new Date(new Date + 3600000);
    let locale = 'ar';
    let week = d.toLocaleDateString(locale, { weekday: 'long' });
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
    let _uptime = process.uptime() * 1000;
    let uptime = clockString(_uptime);
    let user = global.db.data.users[m.sender];
    let name = conn.getName(m.sender);
    let { exp, limit, level, role } = user;
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length;
    let mentionId = m.key.participant || m.key.remoteJid;

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });

    const image = 'https://files.catbox.moe/c2hupv.jpg';

    conn.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: { title: `🌀 𝗖𝗢𝗞𝗨 𝗕𝗢𝗧 | القائمة` },
                    body: {
                        text: `
╔══ ❖ بياناتك ❖ ══╗
⟡ الاسم: ${name}
⟡ المعرف: @${mentionId.split('@')[0]}
⟡ الحالة: ${user.premiumTime > 0 ? 'مميز ✨' : (isPrems ? 'مميز ✨' : 'عادي')}
⟡ المستوى: ${level}
⟡ الرتبة: ${role}
⟡ الخبرة: ${exp}
⟡ الألماس: ${limit}
╚═════════════════╝

╔══ ❖ البـــوت ❖ ══╗
⟡ الاسم: COKU BOT ⚙️
⟡ المطور: محمد عادل 👨‍💻
⟡ وقت التشغيل: ${uptime}
⟡ المستخدمين: ${rtotalreg}
╚═════════════════╝
                        `.trim(),
                        subtitle: "🔹 اختر القسم الذي تريده من القوائم أدناه 🔹"
                    },
                    header: {
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({ image: { url: image } }, { upload: conn.waUploadToServer }, { quoted: m }))
                    },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: false
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '📂 القوائم الرئيسية',
                                    sections: [
                                        {
                                            title: '🌟 الأقسام المتوفرة',
                                            highlight_label: '𝗖𝗢𝗞𝗨 𝗕𝗢𝗧',
                                            rows: [
                                                { header: '👤 العضويات', title: '👥 الأعضاء - بياناتك ومستواك وألماسك', id: '.قسم-الاعضاء' },
                                                { header: '🛡️ الإدارة', title: '🧰 المشرفين - التحكم بالمجموعات والأعضاء', id: '.قسم-المشرفين' },
                                                { header: '🕌 الدين', title: '📿 الدين - أذكار، قرأن، أحاديث، قبلة', id: '.قسم-الدين' },
                                                { header: '💻 المطور', title: '👑 المطور - أوامر خاصة للمطور', id: '.قسم-المطور' },
                                                { header: '⬇️ التنزيل', title: '📥 التنزيلات - تحميل من تيك توك، يوتيوب، فيسبوك', id: '.قسم-التنزيلات' },
                                                { header: '🎮 اللعب', title: '🕹️ الألعاب - مسابقات وتحديات ممتعة', id: '.قسم-الالعاب' },
                                                { header: '🔁 تحويلات', title: '🔄 التحويلات - تحويل الصور، الصوت، الملصقات', id: '.قسم-التحويلات' },
                                                { header: '🤖 الذكاء', title: '🧠 الذكاء الاصطناعي - دردش مع غوكو أو ندي', id: '.قسم-الذكاء' },
                                                { header: '🆘 الدعم', title: '📞 الدعم والمساعدة - حل مشاكل، شرح أوامر', id: '.قسم-الدعم' },
                                                { header: '🔎 البحث', title: '📚 البحث - بحث عن صور، أنمي، ملفات، جوجل', id: '.قسم-البحث' }
                                            ]
                                        }
                                    ]
                                }),
                                messageParamsJson: ''
                            },
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '⚙️ أدوات متقدمة',
                                    sections: [
                                        {
                                            title: '🧩 أدوات النظام',
                                            highlight_label: '𝗖𝗢𝗞𝗨 𝗕𝗢𝗧',
                                            rows: [
                                                { header: '📡 البنج', title: '📶 بنج - سرعة استجابة البوت', id: '.بنج' },
                                                { header: '💾 السيرفر', title: '🔧 حالة السيرفر - معلومات أداء الخادم', id: '.السيرفر' },
                                                { header: '⏳ الوقت', title: '🕒 وقت التشغيل - مدة عمل البوت', id: '.المدة' },
                                                { header: '👥 النشاط', title: '👑 أكثر المستخدمين - النشاط والتحليل', id: '.النشاط' },
                                                { header: '📈 الذروة', title: '📅 وقت الذروة - أنشط وقت لاستخدام البوت', id: '.وقت-الذروة' }
                                            ]
                                        }
                                    ]
                                }),
                                messageParamsJson: ''
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "📣 قناة البوت",
                                    url: "https://whatsapp.com/channel/0029Vb0WYOu2f3EAb74gf02h",
                                    merchant_url: "https://whatsapp.com/channel/0029Vb0WYOu2f3EAb74gf02h"
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "👥 جروب البوت",
                                    url: "https://chat.whatsapp.com/YourBotGroupInviteLink",
                                    merchant_url: "https://chat.whatsapp.com/YourBotGroupInviteLink"
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "👨‍💻 المطور",
                                    url: "https://wa.me/249967185716",
                                    merchant_url: "https://wa.me/249967185716"
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {});
}

handler.help = ['menu'];
handler.tags = ['main'];
handler.command = ['menu', 'مهام', 'اوامر', 'الاوامر', 'قائمة', 'القائمة'];

export default handler;