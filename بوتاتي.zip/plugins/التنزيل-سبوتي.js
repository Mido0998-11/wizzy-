import axios from 'axios';

async function downloadTrack(url) {
    const apiUrl = 'https://spotymate.com/api/download-track';
    const data = {
        url: url
    };
    const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://spotymate.com/'
    };

    try {
        const response = await axios.post(apiUrl, data, { headers: headers });
        return response.data;
    } catch (error) {
        throw new Error(error.response ? error.response.data : error.message);
    }
}

const handler = async (m, { conn, text }) => {
    if (!text) return m.reply('⎆ `هـات لـيـنـك الاغـنـيـة مـن سـبـوتـيـفـاي` 🍨\n\n> *▷  مـثـال :*\n *.سبوتيفاي* https://open.spotify.com/track/6cHCixTkEFATjcu5ig8a7I');

    try {
        const result = await downloadTrack(text);
        
        if (!result.file_url) {
            return m.reply('`لـا يـمـكـن الـوصـول الـي مـلـف الـصـوت` ☘️');
        }

        await conn.sendMessage(m.chat, {
            audio: { url: result.file_url },
            mimetype: 'audio/mpeg',
            filename: 'downloaded_audio.mp3'
        }, { quoted: m });

    } catch (error) {
        m.reply(`ايرور: ${error.message}`);
    }
};

handler.help = ['spotify <url>'];
handler.tags = ['downloader']
handler.command = ['سبوتي', 'سبوتيفاي'];
handler.limit = false;

export default handler;