function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms % 3600000 / 60000);
  let s = Math.floor(ms % 60000 / 1000);
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

const handler = async (m, { conn }) => {
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);

  const text = `
╔═「 ⏱️ وقت التشغيل 」
║ تم تشغيل البوت منذ: *${uptime}*
╚══════════════════════
`.trim();

  await conn.sendMessage(m.chat, { text }, { quoted: m });
};

handler.help = ['المدة'];
handler.tags = ['info'];
handler.command = ['المدة', 'uptime'];

export default handler;