let handler = async (m, { conn }) => {
  let txt = '📋 اختار اللي تحب تعمله من القايمة دي:';

  const buttons = [
    { buttonId: '.تنظيف', buttonText: { displayText: '🧹 تنظيف الشات' }, type: 1 },
    { buttonId: '.قائمة', buttonText: { displayText: '📄 عرض القائمة' }, type: 1 },
    { buttonId: '.شغل اغنية', buttonText: { displayText: '🎶 تشغيل أغنية' }, type: 1 },
    { buttonId: '.ايقاف', buttonText: { displayText: '⛔ إيقاف التشغيل' }, type: 1 },
    { buttonId: '.المطور', buttonText: { displayText: '👨‍💻 المطور' }, type: 1 }
  ];

  await conn.sendMessage(m.chat, {
    text: txt,
    footer: '📍 بوت وسكي V1',
    buttons: buttons,
    headerType: 1
  }, { quoted: m });
};

handler.command = /^قائمة|menu|start$/i;
export default handler;