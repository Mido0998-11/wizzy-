const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys')

module.exports = {
  name: ['تذكرة', 'بلاغ', 'شكوى'],
  category: 'الخدمات',
  async run(m, { conn, text, prefix, command }) {
    const المطور = '249967185716' // رقم المطور

    if (!text) return m.reply('📮 أرسل رسالتك بعد الأمر\nمثال: تذكرة البوت لا يعمل في المجموعة')

    const نص_الشكوى = `🆘 *طلب دعم جديد!*
━━━━━━━━━━━━━━━
👤 *المرسل:* @${m.sender.split('@')[0]}
📨 *الرسالة:* ${text}
🕐 *التاريخ:* ${new Date().toLocaleString('ar-EG')}
━━━━━━━━━━━━━━━
🏷️ *المعرف:* ${m.key.id}`

    // إرسال الشكوى للمطور
    await conn.sendMessage(`${المطور}@s.whatsapp.net`, {
      text: نص_الشكوى,
      mentions: [m.sender]
    })

    // الرد على المستخدم
    return m.reply(
      `🎫 تم إرسال تذكرتك بنجاح إلى فريق الدعم.\nسنرد عليك قريبًا بإذن الله 🙏🏼`
    )
  }
}