let handler = async (m, { conn, participants, usedPrefix, command }) => {
  const reactWait = "⚠️";
  const reactKick = "👢";
  const reactError = "❌";

  const kickMsg = `🚫 *مــنشـن الـشـخص يا نجم !*`;
  const ownerJids = ['249967185716@s.whatsapp.net']; // أرقام المطورين
  const botNumber = conn.user.jid;

  if (!m.mentionedJid[0] && !m.quoted) {
    await m.react(reactWait);
    return m.reply(kickMsg, m.chat, { mentions: conn.parseMention(kickMsg) });
  }

  const user = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;

  if (user === botNumber) {
    await m.react(reactError);
    return m.reply(`😑 *أنا أطرد نفسي؟ إزاي يعني؟ جرب غيري يا نجم.*`);
  }

  if (ownerJids.includes(user)) {
    await m.react(reactError);
    return m.reply(`😎 *عايز تطرد المطور بتاعي؟ مستحيل طبعًا يا نجم.*`);
  }

  try {
    await m.react(reactKick);
    await conn.groupParticipantsUpdate(m.chat, [user], 'remove');

    const groupMetadata = await conn.groupMetadata(m.chat);
    const groupName = groupMetadata.subject || "المجموعة";
    const now = new Date().toLocaleString('ar-EG', {
      timeZone: 'Africa/Khartoum',
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    });

    const caption = `
╭───⌜ ⚡غوكو بوت⚡ ⌟───❯
│ 🏷️ المجموعة: *${groupName}*
│ 🕓 الزمن: *${now}*
│ 🙋‍♂️ تم الطرد بواسطة: @${m.sender.split("@")[0]}
╰───❯👢 تم طــرد العضو بنجاح!
`.trim();

    let profilePic;
    try {
      profilePic = await conn.profilePictureUrl(user, 'image');
    } catch {
      profilePic = 'https://telegra.ph/file/6880771a42bad09dd6087.jpg'; // صورة افتراضية لو مافي صورة
    }

    await conn.sendMessage(
      m.chat,
      {
        image: { url: profilePic },
        caption: caption,
        mentions: [m.sender]
      },
      { quoted: m }
    );

  } catch (e) {
    console.error(e);
    await m.react(reactError);
    await m.reply(`❌ *فشل في تنفيذ أمر الطرد. تأكد أنني أدمن والمستخدم موجود.*`);
  }
};

handler.help = ['kick @user'];
handler.tags = ['group'];
handler.command = ['kick', 'طرد', 'كسمو', 'بره', 'خرجو', 'طلعو', 'غورو', 'مشيه'];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

export default handler;