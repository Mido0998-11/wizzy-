import { exec } from 'child_process'

let handler = async (m, { conn }) => {
  let pingMsg = await conn.sendMessage(m.chat, {
    text: `*⌬ 『 📡 』جـارٍ الفحص ...*\n\n╰┈➤ ⚙️ *يُرجى الانتظار قليلًا...*\n𓆩💠⌯ مـن تطويـر: 𓂃『 ᯓ͡ويـزي ⚡ 』`
  })

  let secondsPassed = 0

  let interval = setInterval(async () => {
    secondsPassed++

    let fakeLatency = (Math.random() * (190 - 90) + 90).toFixed(1)

    let indicator = '🟢'
    if (fakeLatency > 150) indicator = '🟡'
    if (fakeLatency > 180) indicator = '🔴'

    let styledLatency = fakeLatency.replace(/[0-9.]/g, d => ({
      '0': '𝟎', '1': '𝟏', '2': '𝟐', '3': '𝟑', '4': '𝟒',
      '5': '𝟓', '6': '𝟔', '7': '𝟕', '8': '𝟖', '9': '𝟗', '.': '.'
    }[d]))

    let styledSeconds = secondsPassed.toString().replace(/[0-9]/g, d => ({
      '0': '𝟎', '1': '𝟏', '2': '𝟐', '3': '𝟑', '4': '𝟒',
      '5': '𝟓', '6': '𝟔', '7': '𝟕', '8': '𝟖', '9': '𝟗'
    }[d]))

    try {
      let messageText =
        secondsPassed < 10
          ? `*⚡︙سُرعة الإتصـال:* ${styledLatency} 𝒎𝒔 ${indicator}\n\n⌬ 『⏱』الوقت المنقضي: ${styledSeconds} ثـانية\n╰┈➤ 🧪 جـارٍ الفحص ...\n𓆩⚙️⌯ المطـوّر: ᯓ͡ويـزي ⚡`
          : `*⚡︙سُرعة الإتصـال:* ${styledLatency} 𝒎𝒔 ${indicator}\n\n⌬ 『⏱』الوقت: ${styledSeconds} ثـانية\n╰┈➤ ✔️ تـم الفحص بنجاح\n𓆩⚙️⌯ المطـوّر: ᯓ͡ويـزي ⚡`

      await conn.relayMessage(m.chat, {
        protocolMessage: {
          key: pingMsg.key,
          type: 14,
          editedMessage: { conversation: messageText }
        }
      }, {})

      if (secondsPassed >= 10) clearInterval(interval)

    } catch (err) {
      clearInterval(interval)
    }

  }, 1000)
}

handler.help = ['ping']
handler.tags = ['main']
handler.command = ['بينج', 'بنج']

export default handler