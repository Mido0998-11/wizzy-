import fetch from 'node-fetch';

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender];

  // نظام الحد اليومي
  user.apkDownloads = user.apkDownloads || { count: 0, lastDay: 0, limit: 2 };
  let today = new Date().toLocaleDateString('en-GB');

  if (user.apkDownloads.lastDay !== today) {
    user.apkDownloads.lastDay = today;
    user.apkDownloads.count = 0;
  }

  if (!user.premium && !user.developer) {
    user.apkDownloads.limit = user.apkDownloads.limit || 2;
    if (user.apkDownloads.count >= user.apkDownloads.limit) {
      throw `✶ لقد وصلت إلى الحد اليومي المسموح (${user.apkDownloads.limit} تطبيقات).\n⏳ سيتم التصفير غدًا تلقائيًا.\n\n⌯ استخدم الأمر: *.كم_تبقى_لي* لمتابعة عدد تحميلاتك دائمًا.`;
    }
  }

  if (!args[0]) throw `✶ مثال:\n➥ ${usedPrefix + command} facebook lite`;

  let info = await apkinfo(text);
  let res = await apk(text);

  if (res.size > 993000000) {
    m.react('⚠️');
    throw '✶ الملف كبير جدًا!\n➥ الحد الأقصى للحجم هو 990 ميغابايت.';
  }

  let appSizeMB = (res.size / (1024 * 1024)).toFixed(2);

  await conn.sendMessage(m.chat, {
    image: { url: info.icon },
    caption: `╭──〔 *📱 معلومات التطبيق* 〕──
│
│ ✦ الاسم: *${info.name}*
│ ✦ الباكيج: *${info.packageN}*
│ ✦ التحميلات: *${info.downloads.toLocaleString()}*
│ ✦ الحجم: *${appSizeMB} MB*
│
╰────────────────────╯`,
    footer: '✶ 𝐂𝐎𝐊𝐔 𝐁𝐎𝐓 ✶',
  });

  await conn.sendMessage(m.chat, {
    text: `⌯ جاري تحميل التطبيق: *${info.name}*\n\n⏳ انتظر قليلاً وسيتم إرسال الملف...\n\n✦ شكراً لاستخدامك *COKU BOT*، نسعد بخدمتك دائمًا!`,
  });

  await conn.sendMessage(
    m.chat,
    { document: { url: res.download }, mimetype: res.mimetype, fileName: res.fileName },
    { quoted: m }
  );

  if (!user.premium && !user.developer) user.apkDownloads.count++;
};

handler.command = /^(apk|تطبيق)$/i;
handler.help = ['apk'];
handler.tags = ['downloader'];
handler.premium = false;
export default handler;

async function apkinfo(url) {
  let res = await fetch('http://ws75.aptoide.com/api/7/apps/search?query=' + encodeURIComponent(url) + '&limit=1');
  let $ = await res.json();

  if (!$.datalist || !$.datalist.list || $.datalist.list.length === 0)
    throw '✶ لم يتم العثور على التطبيق المطلوب.';

  let app = $.datalist.list[0];

  return {
    icon: app.icon,
    name: app.name,
    packageN: app.package,
    downloads: app.stats && app.stats.downloads ? app.stats.downloads : 0,
    obb: !!(app.obb && app.obb.main),
    obb_link: app.obb && app.obb.main ? app.obb.main.path : '_غير موجود_',
  };
}

async function apk(url) {
  let res = await fetch('http://ws75.aptoide.com/api/7/apps/search?query=' + encodeURIComponent(url) + '&limit=1');
  let $ = await res.json();
  let app = $.datalist.list[0];

  let fileName = app.package + '.apk';
  let download = app.file.path;
  let head = await fetch(download, { method: 'head' });
  let size = head.headers.get('content-length');
  let mimetype = head.headers.get('content-type');

  if (!download) throw '✶ لم أتمكن من تحميل ملف الـ APK.';
  return { fileName, mimetype, download, size };
}