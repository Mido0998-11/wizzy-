import fetch from 'node-fetch'
import cheerio from 'cheerio'

let handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) throw `╭─❖ 『 *📸 GOKU BOT - Pinterest* 』
│ ✦ أرسل اسم الصورة التي تريد تحميلها.
│ ✦ سيتم جلب أفضل الصور من Pinterest.
│
│ ✦ مثال: *${usedPrefix + command} فراشة*
╰───────────────❖`

  await m.react('🔍')
  conn.reply(m.chat, '⌯ جاري جلب أجمل الصور من Pinterest ...', m)

  try {
    const hasil = await pinterest(text)
    if (!hasil.length) throw '❌ لم يتم العثور على صور، حاول بكلمة أخرى.'

    const shuffled = hasil.sort(() => Math.random() - 0.5)
    const selected = shuffled.slice(0, 10)

    for (let i = 0; i < selected.length; i++) {
      await conn.sendFile(m.chat, selected[i], 'goku.jpg', `✨ *Pinterest Result*\n🔍 *${text}*\n🧠 *GOKU BOT*`, m)
      await new Promise(r => setTimeout(r, 500)) // تأخير بسيط
    }

    await m.react('✅')

  } catch (e) {
    console.error(e)
    await m.react('❌')
    conn.reply(m.chat, '❌ حدث خطأ أثناء جلب الصور، حاول لاحقًا.', m)
  }
}

handler.help = ['صور <الاسم>']
handler.tags = ['بحث']
handler.command = /^صور$/i
handler.diamond = true
handler.limit = 3

export default handler

async function pinterest(text) {
  try {
    const res = await fetch(`https://id.pinterest.com/search/pins/?autologin=true&q=${encodeURIComponent(text)}`)
    const html = await res.text()
    const $ = cheerio.load(html)
    const results = []

    $('img').each((i, el) => {
      const src = $(el).attr('src')
      if (src && src.includes('236x')) {
        results.push(src.replace(/236x/g, '736x'))
      }
    })

    return results.filter((v, i, a) => v && a.indexOf(v) === i) // إزالة التكرارات والروابط الفارغة
  } catch (err) {
    throw err
  }
}