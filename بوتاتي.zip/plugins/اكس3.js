let handler = async (m, { conn, usedPrefix, command }) => {
  conn.game = conn.game || {}; // تأكد من وجود conn.game

  // العثور على الغرفة التي يشارك فيها المستخدم
  let room = Object.values(conn.game).find(room => 
    room?.id?.startsWith('tictactoe') &&
    (room?.game?.playerX === m.sender || room?.game?.playerO === m.sender)
  );

  // إذا لم يكن في غرفة
  if (!room) {
    return m.reply('❌ أنت لست داخل أي لعبة تيك تاك تو حالياً.');
  }

  // حذف الغرفة
  delete conn.game[room.id];
  await m.reply('✅ تم حذف الغرفة بنجاح.');
};

handler.command = /^(احذف_اكس|حذفف|delxo|deltictactoe)$/i;
handler.fail = null;
export default handler;